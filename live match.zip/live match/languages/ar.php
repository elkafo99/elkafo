<?php

#language : Arabic - العربية

// language settings
$lang_direction                    = "rtl"                                         ; 
$lang_odirection                   = "ltr"                                         ;
$lang_direction2                   = "right"                                       ; 
$lang_shortcut                     = "ar"                                          ; 
$lang_odirection2                  = "left"                                        ; 

$lang_your_email                   = "بريدك الإلكتروني"                             ;
$lang_password                     = "كلمة المرور"                                 ;
$lang_password_again               = "أعد كتابة كلمة المرور"                       ;
$lang_username                     = "اسم المستخدم"                                ;
$lang_login                        = "الدخول"                                      ;
$lang_remember_me                  = "تذكرني"                                      ;
$lang_register                     = "التسجيل"                                     ;
$lang_login_failed                 = "اسم المستخدم, كلمة المرور أو كلاهما خطأ"      ;
$lang_welcome                      = "أهلاً وسهلاً"                                    ;
$lang_member_control_panel         = "لوحة التحكم"                                 ;
$lang_logout                       = "تسجيل الخروج"                                ;
$lang_logout_done                  = "تم تسجيل الخروج بنجاح"                       ;
$lang_if_nredirect5sec             = "اذ لم يتم تحويلك تلقائياً اضغط هنا"           ;
 
$lang_edit                         = "تعديل"                                       ;
$lang_update                       = "تحديث"                                       ;
$lang_empty_fields                 = "هناك حقول مطلوبة فاضية"                      ;
$lang_password_no_match            = "كلمة المرور الأولى غير متطابقة مع الثانية"    ;
$lang_done                         = "تم بنجاح"                                    ;
$lang_failed                       = "فشلت العملية"                                ;
$lang_your_personal_notes          = "ملاحظاتك"                                     ;
$lang_date                         = "التاريخ"                                     ;
$lang_member_profile               = "الملف الشخصي"                                ;
$lang_url                          = "الرابط"                                      ;
$lang_rules                        = "الشروط"                                      ;
$lang_register_done                = "تم التسجيل بنجاح , يمكنك الآن تسجيل الدخول"   ;
$lang_email_isset                  = "البريد الإلكتروني موجود مسبقاً"                ;
$lang_mosharakat                   = "المشاركات"                                   ;
$lang_topics                       = "المباريات"                                     ;
 
 
$lang_category_title               = "عنوان القسم"                                 ;
$lang_topics_total                 = "عدد المباريات"                                 ;
 
 
$lang_categories_total             = "عدد الأقسام"                                  ;
$lang_send_topics                  = "إرسال مباراة"                                  ;

$lang_latest_topics                = "مباريات اليوم"                                 ;


$lang_most_rated                   = "الأكثر تقييماً"                                ;
$lang_topic                        = "مباراة"                                      ;
 
 
 
$lang_empty                        = "فارغ"                                        ;
 
$lang_rate                         = "التقييم"                                     ;
 
$lang_coments                      = "التعليقات"                                   ;
$lang_coments_diabled              = "التعليقات مقفلة"                             ;
$lang_no_coments                   = "لا توجد تعليقات"                              ;
$lang_guest                        = "زائر"                                        ;
$lang_submit                       = "إرسال"                                       ;
$lang_coment_added                 = "تم إضافة التعليق بنجاح"                      ;
$lang_title                        = "العنوان"                                     ;
$lang_category                     = "القسم"                                       ;
$lang_sec_code                     = "كود التحقق"                                  ;
$lang_wrong_sec_code               = "كود التحقق خطأ"                              ;
$lang_allow_coments                = "السماح بالتعليقات"                           ;
$lang_yes                          = "نعم"                                         ;
$lang_no                           = "لا"                                           ;
$lang_thankyou                     = "شكراً لك"                                     ;
$lang_username_isset               = "اسم المستخدم موجود مسبقاً"                    ;
$lang_contactus                    = "مراسلة الإدارة"                               ;
$lang_from                         = "من"                                          ;
$lang_message                      = "الرسالة"                                     ;
$lang_subject                      = "الموضوع"                                     ;
$lang_waiting_accept               = "بانتظار الموافقة من قبل الإدارة"              ;
$lang_pages                        = "الصفحات"                                     ;
$lang_categories                   = "الأقسام"                                      ;
$lang_short_desc                   = "وصف مختصر"                                   ;
 
 
 
 
$lang_size                         = "الحجم"                                       ;
 
$lang_image                        = "الصورة"                                      ;
$lang_company                      = "الشركة المنتجة"                              ;
 
$lang_added_by                     = "بواسطة"                                      ;
 
$lang_back                         = "الخلف"                                       ;
$lang_capability                   = "التوافق"                                     ;
$lang_reset                        = "إفراغ الحقول"                                ;
$lang_latest                       = "الجديد"                                      ;
 
 
 
$lang_save                         = "حفظ"                                         ;
$lang_total_sounds                 = "عدد الأصوات"                                  ;
$lang_odt                          = "المكتب المفتوح"                              ;
 
 
 
$lang_optional                     = "اختياري"                                     ;
$lang_images                       = "الصور"                                       ;
$lang_total_images                 = "عدد الصور"                                   ;
$lang_send_image                   = "إرسال صورة"                                  ;
$lang_thumb                        = "صورة مصغرة"                                  ;
$lang_more                         = "المزيد"                                      ;
$lang_latest_images                = "أحدث الصور"                                 ;
$lang_videos                       = "المرئيات"                                    ;
 
 
$lang_duration                     = "المدة"                                       ;
 
$lang_related_videos               = "مقاطع متشابهة"                               ;
$lang_links                        = "وصلات"                                        ;
$lang_embed                        = "مضمن"                                        ;
$lang_views                        = "المشاهدات"                                   ;
$lang_video_url_inf                = "يمكنك وضع رابط مباشرة mp4,flv أو رابط فيديو من يوتيوب";
$lang_latest_videos                = "أحدث المقاطع"                                ;
$lang_flash_library                = "الفلاشات"                                     ;
$lang_latest_flashes               = "أحدث الفلاشات"                                 ;
 
$lang_newest                       = "الأحدث"                                       ;
$lang_view_full_screan             = "عرض على كامل الشاشة"                         ;
$lang_send_flash                   = "إرسال فلاش"                                   ;
$lang_weblinks                     = "دليل المواقع"                                ;
$lang_total_websites               = "عدد المواقع"                                 ;
$lang_wrong_page                   = "صفحة غير صحيحة"                              ;
$lang_site_name                    = "اسم الموقع"                                  ;
$lang_visits                       = "الزيارات"                                    ;
$lang_alexa_rate                   = "تقييم أليكسا"                                ;
$lang_visit_site                   = "زيارة الموقع"                                ;
$lang_index                        = "الصفحة الرئيسية"                             ;
$lang_send_site                    = "ارسل موقع"                                   ;
$lang_private_msgs                 = "الرسائل الخاصة"                              ;
$lang_write_msg                    = "كتابة رسالة"                                 ;
$lang_recieved_msgs                = "الرسائل المستلمة"                            ;
$lang_sent_msgs                    = "الرسائل الصادرة"                             ;
$lang_delete                       = "حذف"                                         ;
$lang_to                           = "إلى"                                         ;
$lang_wrong_username               = "اسم المستخدم غير صحيح"                       ;
$lang_pmsg_sent                    = "تم إرسال الرسالة بنجاح"                      ;
$lang_answer_msg                   = "الـرد على الرسالة"                           ;
$lang_search                       = "البحث"                                       ;
$lang_in                           = "في"                                          ;
$lang_all_categories               = "كل الأقسام"                                   ;
$lang_results_total                = "عدد النتائج"                                 ;
$lang_no_results                   = "لا توجد نتائج"                                ;
$lang_members                      = "الأعضاء"                                      ;
$lang_pages                        = "الصفحات"                                     ;
$lang_categ_disabled               = "هذا القسم معطل"                              ;
$lang_languages                    = "اللغات"                                      ;
$lang_themes                       = "المظاهر"                                     ;
$lang_site_closed                  = "الموقع مغلق"                                 ;
$lang_membertitle                  = "لقب العضو"                                   ;
$lang_edara                        = "الإدارة"                                      ;
$lang_confirm                      = "هل أنت متأكد ?"                              ;
$lang_previous                     = "السابق"                                      ;
$lang_next                         = "التالي"                                      ;
$lang_date_hijri                   = "هـ"                                          ;
$lang_date_hijri_fullform          = "هجري"                                        ;
$lang_date_christian               = "مـ"                                          ;
$lang_date_christian_fullform      = "ميلادي"                                       ;
$lang_ip                           = "الآي بي"                                      ;
$lang_online_vam                   = "المتواجدين حالياً"                            ;
$lang_online_members               = "الأعضاء"                                      ;
$lang_online_guests                = "الزوار"                                      ;
$lang_member_status                = "الحالة"                                      ;
$lang_member_online                = "متواجد"                                      ;
$lang_member_offline               = "غير متواجد"                                  ;
$lang_categorie_type               = "نوع القسم"                                   ;
$lang_categorie_type_main          = "قسم رئيسي"                                   ;
$lang_categorie_type_sub           = "قسم فرعي"                                    ;
// new phrases in afm v2,2
$lang_share_facebook               = "شارك الصفحة في فيس بوك"                      ;
$lang_share_twitter                = "شارك الصفحة في تويتر"                        ;
$lang_share_google                 = "شارك الصفحة في جوجل"                         ;
$lang_share_email                  = "ارسل الصفحة لصديق"                           ;
$lang_share_more                   = "المزيد"                                      ;
$lang_share_bookmark               = "أضف إلى المفضلة"                             ;
$lang_subt_categories              = "الأقسام الفرعية"                              ;
$lang_open_in_new_window           = "افتحه في نافذة جديدة"                        ;

// control panel phrases 
$lang_cp_admincp                   = "لوحة تحكم الإدارة"                            ;
$lang_cp_login_done                = "تم تسجيل الدخول بنجاح"                       ;
$lang_cp_login_failed              = "اسم المستخدم أو كلمة المرور أو كلاهما خطأ"    ;
$lang_cp_site_information          = "معلومات الموقع"                              ;
$lang_cp_php_version               = "إصدار البي اتش بي"                           ;
$lang_cp_afm_version              = "إصدار البرنامج"                              ;
$lang_cp_waiting_moderation        = "بانتظار الموافقة"                            ;
$lang_cp_admin_notes               = "ملاحظات المدير"                               ;
$lang_cp_main_settings             = "الإعدادات العامة"                             ;
$lang_cp_enable_disable_categories = "تفعيل \ تعطيل الأقسام"                        ;
$lang_cp_blocks                    = "القوائم"                                     ;
$lang_cp_manage_blocks             = "التحكم في القوائم"                           ;
$lang_cp_manage_members            = "التحكم في الأعضاء"                            ;
$lang_cp_registration_rules        = "شروط التسجيل"                                ;
$lang_cp_languages                 = "اللغات"                                      ;
$lang_cp_themes                    = "المظاهر"                                     ;
$lang_cp_manage_categories         = "التحكم في الأقسام"                            ;
$lang_cp_site_url                  = "رابط الموقع"                                 ;
$lang_cp_activate_ajax             = "تفعيل الأجاكس "                 ;
$lang_cp_activate_members          = "تفعيل نظام الأعضاء"                           ;
$lang_cp_comments_guests_activate  = "السماح للزوار بالتعليق"                      ;
$lang_cp_admin_email               = "البريد الإلكتروني"                            ;
$lang_cp_favicon                   = "شعار صغير"                                   ;
$lang_cp_enabled                   = "مفعل"                                        ;
$lang_cp_disabled                  = "معطل"                                        ;
$lang_cp_index_msgs                = "الرسائل في الصفحة الرئيسية"                  ;
$lang_cp_meta_keywords             = "الكلمات الدليلة - keywords"                  ;
$lang_cp_close_site                = "إغلاق الموقع"                                 ;
$lang_cp_settings                  = "الإعدادات"                                    ;
$lang_cp_close_registration        = "إغلاق التسجيل"                                ;
$lang_cp_defult_lang               = "اللغة الافتراضية"                             ;
$lang_cp_defult_theme              = "المظهر الافتراضي"                             ;
$lang_cp_file                      = "الملف"                                       ;
$lang_cp_add                       = "إضافة"                                       ;
$lang_cp_content                   = "المحتوى"                                     ;
$lang_cp_manage                    = "التحكم"                                      ;
$lang_cp_position                  = "المكان"                                      ;
$lang_order                        = "الترتيب"                                     ;
$lang_cp_page                      = "الصفحة"                                      ;
$lang_cp_without_file              = "بدون ملف"                                    ;
$lang_cp_all_pages                 = "كل الصفحات"                                  ;
$lang_cp_left                      = "اليسار"                                      ;
$lang_cp_right                     = "اليمين"                                      ;
$lang_cp_top                       = "الأعلى"                                       ;
$lang_cp_down                      = "الأسفل"                                       ;
$lang_cp_center                    = "الوسط"                                       ;
$lang_cp_autoactivate              = "التفعيل التلقائي"                            ;
$lang_cp_autoactivate_desc         = "في حال اخترت نعم مشاركات هذا العضو ستدخل مباشرة في الموقع دون الحاجة إلى موافقة الإدارة";
$lang_cp_html_allowed              = "html متاح"                                   ;
$lang_cp_alretba                   = "رتبة العضو"                                  ;
$lang_cp_alretba_member            = "عضو"                                         ;
$lang_cp_alretba_admin             = "مدير"                                        ;
$lang_cp_alretba_caseadmin         = "في حال جعلت العضو مدير سيتمكن من دخول لوحة تحكم الإدارة";
$lang_cp_allow_users_send          = "السماح للأعضاء بإرسال"                        ;
$lang_cp_results_per_pg            = "النتائج في كل صفحة"                          ;
$lang_cp_show_mem_signs            = "عرض تواقيع الأعضاء"                           ;
$lang_cp_accept                    = "موافقة"                                      ;
$lang_cp_colums                    = "الأعمدة"                                      ;
$lang_cp_vid_logo                  = "شعار الموقع"                                 ;
$lang_cp_db_backup                 = "نسخ احتياطي"                                 ;
$lang_cp_database                  = "قاعدة البيانات"                              ;
$lang_cp_mesages                   = "الرسائل"                                     ;
 
$lang_cp_title                     = "لوحة تحكم الموقع"                            ;
$lang_cp_page_link                 = "الرابط"                                      ;
$lang_cp_imp_links                 = "وصلات مهمة"                                   ;
$lang_cp_official_site             = "الموقع الرسمي"                               ;
$lang_cp_support_site              = "الدعم الفني"                                 ;


?>
