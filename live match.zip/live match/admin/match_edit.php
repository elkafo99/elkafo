<?php
if(isset($_GET['edit'])) {
	$wysiwyg = 'yes';
}
include ("common.php");
$cp_pages_query = mysql_query("SELECT * FROM afm_topics_topics ORDER BY id DESC");

$mysql_topics_stpg_query = mysql_query("SELECT * FROM afm_pages ORDER BY id DESC");

if(isset($_GET['del'])) {
mysql_query("DELETE FROM afm_topics_topics WHERE id = '$_GET[id]'") or die(mysql_error());
exit;
}

$plive = $_POST['live'];
if(isset($_GET['doedit'])) {
$gid = $_GET['id'];
$op = mysql_query("UPDATE afm_topics_topics SET title = '$_POST[title]', title2 = '$_POST[title2]', res1 = '$_POST[res1]', res2 = '$_POST[res2]' ,  com = '$_POST[com]'  ,  time = '$_POST[time]', image = '$_POST[image]', image2 = '$_POST[image2]' , page = '$_POST[page]' , date = '$_POST[date]' , content = '$_POST[content]' , vtitle = '$_POST[vtitle]' , link = '$_POST[link]' , live = '$plive' WHERE id = '$gid'");
if($op) {
	print '<div class="greenbox">'.$lang_done.'</div>';
 
}
}
if(isset($_GET['edit'])) {
$wysiwyg = 'yes';
$mysql_editpg78_query = mysql_query("SELECT * FROM afm_topics_topics WHERE id = '$_GET[id]'");
$mysql_editpg78_row  = mysql_fetch_array($mysql_editpg78_query);
?>

  <link rel="stylesheet" href="jquery-ui.css" />
  <script src="jquery-1.9.1.js"></script>
  <script src="jquery-ui3.js"></script>
  
 
  <script>
  $(function() {
    $( "#datepicker" ).datepicker();
  });
  
 
  
  </script>

<form action="?doedit&id=<?php echo $_GET['id']; ?>" method="post" target="page">
<table class="table_3" width="100%">
<tr><td class="table_3_title" colspan="3"><?php print $lang_edit; ?></td></tr>


<tr><td>مباشر</td><td>:</td><td>
<select name="live">
<option value="yes" <?php if($mysql_editpg78_row['live'] == 'yes') { print 'SELECTED'; } ?>><?php print $lang_yes; ?></option>
<option value="no" <?php if($mysql_editpg78_row['live'] == 'no') { print 'SELECTED'; } ?>><?php print $lang_no; ?></option>
</select>
</td></tr>


<tr><td width="20%">الفريق الاول</td><td width="1">:</td><td><input name="title" type="text" size="30" value="<?php print $mysql_editpg78_row['title']; ?>" /></td></tr>

<tr><td width="20%">الفريق الثاني</td><td width="1">:</td><td><input name="title2" type="text" size="30" value="<?php print $mysql_editpg78_row['title2']; ?>" /></td></tr>


<tr><td width="20%">اهداف الفريق الاول</td><td width="1">:</td><td><input name="res1" type="text" size="30" value="<?php print $mysql_editpg78_row['res1']; ?>" /></td></tr>

<tr><td width="20%">اهداف الفريق الثاني</td><td width="1">:</td><td><input name="res2" type="text" size="30" value="<?php print $mysql_editpg78_row['res2']; ?>" /></td></tr>

<tr><td width="20%">تاريخ المباراة</td><td width="1">:</td><td><input name="date"  id="datepicker"  type="text" size="30" value="<?php print $mysql_editpg78_row['date']; ?>" /></td></tr>

<tr><td width="20%">توقيت المباراة</td><td width="1">:</td><td><input name="time" type="text" size="30" value="<?php print $mysql_editpg78_row['time']; ?>" /></td></tr>

<tr><td width="20%">شعار الفريق الاول</td><td width="1">:</td><td><input name="image" type="text" size="30" value="<?php print $mysql_editpg78_row['image']; ?>" /></td></tr>


<tr><td width="20%">شعار الفريق الثاني</td><td width="1">:</td><td><input name="image2" type="text" size="30" value="<?php print $mysql_editpg78_row['image2']; ?>" /></td></tr>


<tr><td width="20%">المعلق</td><td width="1">:</td><td><input name="com" type="text" size="30" value="<?php print $mysql_editpg78_row['com']; ?>" /></td></tr>

<tr><td>القناة</td><td>:</td><td>
<select name="page">
<?php while($row = mysql_fetch_array($mysql_topics_stpg_query)) { ?>
<option value="<?php echo $row['id']; ?>" <?php if($ppage == $row['id']) { echo 'SELECTED'; } ?>><?php print $row['title']; ?></option>
<?php } ?>
</select>
</td></tr>


<tr><td width="20%">عنوان الفيديو</td><td width="1">:</td><td><input name="vtitle" type="text" size="30" value="<?php print $mysql_editpg78_row['vtitle']; ?>" /></td></tr>

<tr><td width="20%">كود الفيديو - يوتيوب</td><td width="1">:</td><td><input name="link" type="text" size="30" value="<?php print $mysql_editpg78_row['link']; ?>" /></td></tr>

<tr><td width="20%"><?php print $lang_cp_content; ?></td><td width="1"></td><td>
<textarea name="content"><?php print $mysql_editpg78_row['content']; ?></textarea>
</td></tr>


<tr><td></td><td></td><td><input type="submit" value="<?php print $lang_edit; ?>" /></td></tr>
</table>
</form>
<?php
exit;
}

?>
<table class="table_3" width="100%">
<tr><td class="table_3_title" colspan="2"><?php print $lang_pages; ?> - <?php print $lang_cp_manage; ?></td></tr>
<?php while($row = mysql_fetch_array($cp_pages_query)) { ?>
<script>
$(document).ready(function() {
	$("#dl<?php echo $row['id']; ?>").click(function(){
		$("#tr<?php echo $row['id']; ?>").css("background","red");
		$("#tr<?php echo $row['id']; ?>").fadeOut("slow");
		$("#tr2<?php echo $row['id']; ?>").css("background","red");
		$("#tr2<?php echo $row['id']; ?>").fadeOut("slow");
		$("#frame").load("?del&id=<?php echo $row['id']; ?>");
	});
	$("#ed<?php echo $row['id']; ?>").click(function(){
		$("#tr<?php echo $row['id']; ?>").css("background","yellow");
		$("#iframe").show();
		$("#iframe").attr("src","?edit&id=<?php echo $row['id']; ?>");
		$("#iframe").attr("height","100%");
	});
});
</script>
<tr id="tr<?php echo $row['id']; ?>"><td width="80%"><?php print $row['title']; ?> - <?php print $row['title2']; ?> - <?php print $row['date']; ?></td><td>
<a id="ed<?php echo $row['id']; ?>" href="#"><?php print $lang_edit; ?></a> / <a id="dl<?php echo $row['id']; ?>" href="#"><?php print $lang_delete; ?></a>
</td></tr>


<?php } ?>
</table>
<span id="frame"></span>
<iframe frameborder="0" width="100%" height="0" id="iframe"></iframe>
