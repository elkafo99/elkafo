<?php
include ("common.php");
if(isset($_GET['del'])) {
@mysql_query("DELETE FROM afm_contactus WHERE id = '$_GET[del]'");
exit;
}
$gshow = $_GET['show'];
$cp_cntctus_pg_query = mysql_query("SELECT * FROM afm_contactus WHERE id = '$gshow'");
$cp_cntctus_pg_row = mysql_fetch_array($cp_cntctus_pg_query);
mysql_query("UPDATE afm_contactus SET readed = 'yes' WHERE id = '$gshow'");
?>

<table class="table_3" width="100%">
<tr class="table_3_title"><td width="19"><img src="theme/images/mail.png" height="18" width="18"/></td><td align="center"><?php print $cp_cntctus_pg_row['subject']; ?></td></tr>
<tr><td colspan="2"><?php print $cp_cntctus_pg_row['sender']; ?> | <?php print $cp_cntctus_pg_row['email']; ?> | <?php print $cp_cntctus_pg_row['date']; ?></td></tr>
<tr><td colspan="2"><hr /></td></tr>
<tr><td colspan="2"><?php print nl2br($cp_cntctus_pg_row['message']); ?></td></tr>
</table>
