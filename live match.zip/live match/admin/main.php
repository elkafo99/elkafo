<?php
include ("common.php");

if(isset($_GET['notes'])) {
$pnotes = $_POST['notes'];
mysql_query("UPDATE afm_control SET notes = '$pnotes'");
}


?>



<table class="table_1" width="100%" align="center">
<tr><td valign="top">
<table class="table_2" width="100%"><tr><td align="center"><?php print $lang_cp_admincp; ?></td></tr></table>

<table class="table_3" width="100%">
<tr><td class="table_3_title" colspan="2"><?php print $lang_cp_site_information; ?></td></tr>
<tr>
<td width="50%"><?php print $lang_cp_php_version; ?> : <?php echo phpversion(); ?></td>
<td><?php print $lang_cp_afm_version; ?> : Live match 1.0</td>
</tr>
</table>




<table class="table_3" width="100%">
<tr class="table_3_title"><td width="19"><img src="theme/images/mail.png" height="18" width="18"/></td>
<td colspan="4">
<?php print $lang_cp_mesages; ?></td></tr>
<?php
$cp_cpmsgscntctus_query = mysql_query("SELECT id,subject,sender,date,readed FROM afm_contactus ORDER BY id DESC");
$altr = '0';
while($row = mysql_fetch_array($cp_cpmsgscntctus_query)) {
$altr = $altr+1;
if($altr == "2") {
$color = "#FFFFFF";
$altr = '0';
} else {
$color = "#DDDDDD";
}
?>
<script>
$(document).ready(function() {
	$("#delmsg<?php echo $row['id']; ?>").click(function() {
		$("#trmsg<?php echo $row['id']; ?>").attr("bgcolor","red");
		$("#trmsg<?php echo $row['id']; ?>").fadeOut("slow");
		$("#frame").load("contactus.php?del=<?php echo $row['id']; ?>");
	});
});
</script>
<tr id="trmsg<?php echo $row['id']; ?>" bgcolor="<?php echo $color; ?>">
<td>
<img src="theme/images/mail<?php if($row['readed'] == 'yes') { print'_readed'; } ?>.png" height="18" width="18"/>
</td>
<td width="60%">
<a href="contactus.php?show=<?php echo $row['id']; ?>"><?php print $row['subject']; ?></a>
</td><td><?php print $row['sender']; ?><td><?php print $row['date']; ?></td><td width="1">
<img src="theme/images/delete.gif" height="18" width="18" id="delmsg<?php echo $row['id']; ?>" style="cursor:pointer;"/>
</td></tr>
<?php } ?>
</table>

<span id="frame"></span>



