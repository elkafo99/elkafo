<?php
include ("common.php");

$cp_topics_settings_query = mysql_query("SELECT * FROM afm_topics_settings");
$cp_topics_settings_row   = mysql_fetch_array($cp_topics_settings_query);


if(isset($_GET['do'])) {
$psitename = $_POST['sitename'];
$paddress = $_POST['address'];
$pajax = $_POST['ajax'];
 
 $ppg = $_POST['topics_per_pg'];

$padmin_email = $_POST['admin_email'];
$pfavicon = $_POST['favicon'];

$op = mysql_query("UPDATE afm_maininfo SET sitename = '$psitename', address = '$paddress', admin_email = '$padmin_email', favicon = '$pfavicon'");

mysql_query("UPDATE afm_topics_settings SET  topics_per_pg = '$ppg'");


if($op) {
	print '<div class="greenbox">'.$lang_done.'</div>';
 	print '<meta http-equiv="refresh" content="0;URL=main.php"> ';
 
} else {
	print 'failed';
}
}

?>

<table class="table_1" width="100%" align="center">
<tr><td valign="top">


<form action="?do" method="post" style="margin:0;">
<table class="table_3" width="100%">
<tr><td class="table_3_title" colspan="3"><?php print $lang_cp_main_settings; ?></td></tr>
<tr>
<td width="30%"><?php print $lang_site_name; ?></td><td width="1">:</td><td><input name="sitename" type="text" size="30" value="<?php print $cp_maininfo_row['sitename']; ?>"/></td>
</tr>
<tr><td><?php print $lang_cp_site_url; ?></td><td>:</td><td><input dir="ltr" name="address" type="text" size="30" value="<?php print $cp_maininfo_row['address']; ?>"/></td></tr>

<tr><td>عدد الفيديوهات الصفحة الرئيسية</td><td>:</td><td><input type="text" name="topics_per_pg" size="5" value="<?php print $cp_topics_settings_row['topics_per_pg']; ?>" /></td></tr>
 
<tr><td><?php print $lang_cp_admin_email; ?></td><td>:</td><td><input name="admin_email" value="<?php print $cp_maininfo_row['admin_email']; ?>" type="text" /></td></tr>
<tr><td><?php print $lang_cp_favicon; ?></td><td>:</td><td><input name="favicon" value="<?php print $cp_maininfo_row['favicon']; ?>" type="text" size="35" dir="ltr"/></td></tr>
<tr><td></td><td></td><td><input type="submit" value="<?php print $lang_update; ?>" /></td></tr>
</table>
</form>

</td></tr>

</table>


