<?php
include ("common.php");

$cp_langauges_query = mysql_query("SELECT * FROM afm_themes ORDER BY id DESC");
$cp_langauges2_query = mysql_query("SELECT * FROM afm_themes ORDER BY id DESC");

if(isset($_GET['langdef'])) {
$op = mysql_query ("UPDATE afm_maininfo SET defult_theme = '$_POST[lang]'");
if($op) {
	print '<div class="greenbox">'.$lang_done.'</div>';
	print '<meta http-equiv="refresh" content="0;URL=success.php"> ';
}
}

if(isset($_GET['langdel'])) {
$gid = $_GET['id'];
mysql_query("DELETE FROM afm_themes WHERE id = '$gid'");
exit;
}
if(isset($_GET['langedit'])) {
$gid = $_GET['id'];
$op = mysql_query("UPDATE afm_themes SET name = '$_POST[name]', file = '$_POST[file]' WHERE id = '$gid'");
if($op) {
	print '<div class="greenbox">'.$lang_done.'</div>';
	print '<meta http-equiv="refresh" content="0;URL=success.php"> ';
}
exit;
}
if(isset($_GET['langed'])) {
$gid = $_GET['id'];
$cp_edlang_query = mysql_query("SELECT * FROM afm_themes WHERE id = '$_GET[id]'");
$cp_edlang_row   = mysql_fetch_array($cp_edlang_query);
?>
<form action="?langedit&id=<?php echo $gid; ?>" method="post">
<table class="table_3" width="100%">
<tr><td class="table_3_title" colspan="3"><?php print $lang_edit; ?> - <?php print $cp_edlang_row['name']; ?></td></tr>
<tr><td width="20%"><?php print $lang_title; ?></td><td width="1">:</td><td><input type="text" name="name" value="<?php print $cp_edlang_row['name']; ?>" /></td></tr>
<tr><td><?php print $lang_cp_file; ?></td><td>:</td><td><input size="10" type="text" name="file" value="<?php print $cp_edlang_row['file']; ?>" /></td></tr>
<tr><td></td><td></td><td><input type="submit" value="<?php print $lang_update; ?>" /></td></tr>
</table>
</form>
<?php
exit;
}

if(isset($_GET['add'])) {
?>
<form action="?doadd" method="post">
<table class="table_3" width="100%">
<tr><td class="table_3_title" colspan="3"><?php print $lang_cp_add; ?> - <?php print $lang_title; ?></td></tr>
<tr><td width="20%"><?php print $lang_title; ?></td><td width="1">:</td><td><input type="text" name="name" /></td></tr>
<tr><td><?php print $lang_cp_file; ?></td><td>:</td><td><input size="10" type="text" name="file" /></td></tr>
<tr><td></td><td></td><td><input type="submit" value="<?php print $lang_cp_add; ?>" /></td></tr>
</table>
</form>
<?php
exit;
}
if(isset($_GET['doadd'])) {
$op = mysql_query("INSERT INTO afm_themes (name, file) VALUES('$_POST[name]', '$_POST[file]') ") or die(mysql_error());
if($op) {
	print '<div class="greenbox">'.$lang_done.'</div>';
	print '<meta http-equiv="refresh" content="0;URL=success.php"> ';
exit;
}
}

?>



<table class="table_3" width="100%">
<tr><td class="table_3_title"><?php print $lang_cp_defult_theme; ?></td></tr>
<tr>
<td>
<form action="?langdef" method="post" style="margin:0;">
<select name="lang">
<?php while($row = mysql_fetch_array($cp_langauges_query)) { ?>
<option value="<?php echo $row['file']; ?>" <?php if($cp_maininfo_row[defult_theme] == $row[file]) { print 'SELECTED'; } ?>><?php print $row['name']; ?></option>
<?php } ?>
</select>
<input value="<?php print $lang_update; ?>" type="submit" />
</form>
</td>
</tr>
</table>

<table class="table_3" width="100%">
<tr><td class="table_3_title" colspan="2"><?php print $lang_themes; ?></td></tr>
<?php while($row = mysql_fetch_array($cp_langauges2_query)) { ?>
<script>
$(document).ready(function() {
	$("#dl<?php echo $row['id']; ?>").click(function(){
		$("#tr<?php echo $row['id']; ?>").css("background","red");
		$("#tr<?php echo $row['id']; ?>").fadeOut("slow");
		$("#frame").load("?langdel&id=<?php echo $row['id']; ?>");
	});
	$("#ed<?php echo $row['id']; ?>").click(function(){
		$("#tr<?php echo $row['id']; ?>").css("background","yellow");
		$("#frame").load("?langed&id=<?php echo $row['id']; ?>");
	});
});
</script>
<tr id="tr<?php echo $row['id']; ?>"><td width="80%"><?php print $row['name']; ?></td><td><a id="ed<?php echo $row['id']; ?>" href="#"><?php print $lang_edit; ?></a> / <a id="dl<?php echo $row['id']; ?>" href="#"><?php print $lang_delete; ?></a></td></tr>
<?php } ?>
<tr>
<td></td>
</tr>
</table>
<script>
$(document).ready(function() {
	$("#addlang").click(function() {
		$("#addlang").css("background","yellow");
		$("#frame").load("?add");
	});
});
</script>
<div id="addlang" class="button_1" onmouseover="this.className='button_1_h'" onmouseout="this.className='button_1'" valign="middle"><img src="theme/images/plus.png" height="16" width="16" /> <?php print $lang_cp_add; ?></div>

<span id="frame"></span>

