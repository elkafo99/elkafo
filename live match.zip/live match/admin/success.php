<?php include ("common.php"); ?>

<center><h1><?php print $lang_done; ?></h1></center>
