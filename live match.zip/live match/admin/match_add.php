<?php
$wysiwyg = "yes";
include ("common.php");

if(isset($_GET['do'])) {
$op = mysql_query("INSERT INTO afm_topics_topics(title, title2, res1,res2,com,image,image2,page,date,time) values('$_POST[title]', '$_POST[title2]', '-', '-', '$_POST[com]', '$_POST[image]' , '$_POST[image2]'  , '$_POST[page]' , '$_POST[date]' , '$_POST[time]'  )");
if($op) {
	print '<div class="greenbox">'.$lang_done.'</div>';
	print '<meta http-equiv="refresh" content="0;URL=success.php"> ';
}
}

$mysql_topics_stpg_query = mysql_query("SELECT * FROM afm_pages ORDER BY id DESC");

?>


  <link rel="stylesheet" href="jquery-ui.css" />
  <script src="jquery-1.9.1.js"></script>
  <script src="jquery-ui3.js"></script>
  
 
  <script>
  $(function() {
    $( "#datepicker" ).datepicker();
  });
  
 
  
  </script>
<form action="?do" method="post" >
<table class="table_3" width="100%">
<tr><td class="table_3_title" colspan="3"><?php print $lang_edit; ?></td></tr>
<tr><td width="20%">الفريق الاول</td><td width="1">         </td><td><input name="title" type="text" size="30" value="<?php print $mysql_editpg78_row['title']; ?>" /></td></tr>

<tr><td width="20%">الفريق الثاني</td><td width="1">         </td><td><input name="title2" type="text" size="30" value="<?php print $mysql_editpg78_row['title2']; ?>" /></td></tr>

<tr><td width="20%">تاريخ المباراة</td><td width="1">         </td><td><input name="date" type="text" id="datepicker" size="30" value="<?php print $mysql_editpg78_row['date']; ?>" /></td></tr>

<tr><td width="20%">توقيت المباراة</td><td width="1">         </td><td><input name="time" type="text" size="30" value="<?php print $mysql_editpg78_row['time']; ?>" /></td></tr>

<tr><td width="20%">شعار الفريق الاول</td><td width="1">         </td><td><input name="image" type="text" size="30" value="<?php print $mysql_editpg78_row['image']; ?>" /></td></tr>


<tr><td width="20%">شعار الفريق الثاني</td><td width="1">         </td><td><input name="image2" type="text" size="30" value="<?php print $mysql_editpg78_row['image2']; ?>" /></td></tr>


<tr><td width="20%">المعلق</td><td width="1">         </td><td><input name="com" type="text" size="30" value="<?php print $mysql_editpg78_row['com']; ?>" /></td></tr>

<tr><td>القناة</td><td>         </td><td>
<select name="page">
<?php while($row = mysql_fetch_array($mysql_topics_stpg_query)) { ?>
<option value="<?php echo $row['id']; ?>" <?php if($ppage == $row['id']) { echo 'SELECTED'; } ?>><?php print $row['title']; ?></option>
<?php } ?>
</select>
</td></tr>

<tr><td></td><td></td><td><input type="submit" value="اضافة" /></td></tr>
</table>
</form>

