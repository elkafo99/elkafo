<?php
session_start();

include ("../connect.php");

if(!$page == 'login') {
if($_SESSION['afm_cp'] == 'yes') { } else {
  print '<meta http-equiv="refresh" content="0;URL=login.php"> ';
exit;
}
}

echo '<title>Control Panel</title>';
if($lang_direction == 'rtl') {
?>

<style>

html {
    background: #424a5d  none repeat scroll 0 0;
}

body {
    overflow:hidden;
}
</style>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />


<frameset cols="80%,20%" frameborder="no">
 

<frame src="main.php"  name="page" scrolling="no" marginwidth="0" marginheight="0">

<frame src="menu.php" name="menu" scrolling="no" marginwidth="0" marginheight="0" namo_target_frame="header">


</frameset>



<?php } else { ?>
<frameset rows="*" cols="5%,18%" frameborder="no">
<frameset rows="0%,23%" cols="*">
<frame src="menu_top.php" name="menu_top" scrolling="no" marginwidth="10" marginheight="14" namo_target_frame="menu_top" scr "menu2.php">
<frame src="menu.php"  name="menu" scrolling="yes" marginwidth="10" marginheight="14">
</frameset>
<frame src="main.php" name="page" scrolling="yes" marginwidth="10" marginheight="14" namo_target_frame="header">
<noframes>
<body bgcolor="#000" text="#000000" link="#0000FF" vlink="#800080" alink="#FF0000">

<p>متصفحك لا يدعم الإيطارات يرجى الدخول من متصفح آخر وننصح باستخدم <a href="http://www.firefox.com">فايرفوكس</a></p>
<p>your browser does not support iframes please use another browser such as <a href="http://www.firefox.com">firefox</a></p>
</body>
</noframes>
</frameset>
<?php } ?>
