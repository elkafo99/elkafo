<?php
$wysiwyg = "yes";
include ("common.php");

if(isset($_GET['do'])) {
$op = mysql_query("INSERT INTO afm_pages(title, content, c2, c3,c4,c5,c6,c7,c8,n1,n2,n3,n4,n5,n6,n7,n8, url) values('$_POST[title]', '$_POST[content]','$_POST[c2]','$_POST[c3]','$_POST[c4]','$_POST[c5]','$_POST[c6]','$_POST[c7]','$_POST[c8]','$_POST[n1]','$_POST[n2]','$_POST[n3]','$_POST[n4]','$_POST[n5]','$_POST[n6]','$_POST[n7]','$_POST[n8]','$_POST[url]')");
if($op) {
	print '<div class="greenbox">'.$lang_done.'</div>';
	print '<meta http-equiv="refresh" content="0;URL=success.php"> ';
}
}

?>

<form action="?do" method="post">
<table class="table_3" width="100%">

<tr><td class="table_3_title" colspan="3"><?php print $lang_pages; ?> - <?php print $lang_cp_add; ?></td></tr>

<tr><td valign="top"><?=$lang_cp_page_link ?></td><td valign="top">:</td><td dir="ltr" align="<?=$lang_direction2; ?>"><?=$cp_maininfo_row['address']; ?>/?p=
<input type="text" name="url" /><br />
</td></tr>

<tr><td width="20%" valign="top">اسم القناة</td><td width="1" valign="top">:</td><td><input type="text" name="title" size="30" /></td></tr>


<tr><td width="20%" valign="top">نوع البث الاول</td><td width="1" valign="top">:</td><td><input type="text" name="n1" size="30" /></td></tr>

<tr><td valign="top"><?php print $lang_cp_content; ?></td><td valign="top">:</td><td><textarea rows="23" name="content"></textarea></td></tr>


<tr><td width="20%" valign="top">نوع البث الثاني</td><td width="1" valign="top">:</td><td><input type="text" name="n2" size="30" /></td></tr>

<tr><td valign="top"><?php print $lang_cp_content; ?></td><td valign="top">:</td><td><textarea rows="23" name="c2"></textarea></td></tr>



<tr><td width="20%" valign="top">نوع البث الثاني</td><td width="1" valign="top">:</td><td><input type="text" name="n3" size="30" /></td></tr>

<tr><td valign="top"><?php print $lang_cp_content; ?></td><td valign="top">:</td><td><textarea rows="23" name="c3"></textarea></td></tr>

<tr><td width="20%" valign="top">نوع البث الثاني</td><td width="1" valign="top">:</td><td><input type="text" name="n4" size="30" /></td></tr>

<tr><td valign="top"><?php print $lang_cp_content; ?></td><td valign="top">:</td><td><textarea rows="23" name="c4"></textarea></td></tr>

<tr><td width="20%" valign="top">نوع البث الثاني</td><td width="1" valign="top">:</td><td><input type="text" name="n5" size="30" /></td></tr>

<tr><td valign="top"><?php print $lang_cp_content; ?></td><td valign="top">:</td><td><textarea rows="23" name="c5"></textarea></td></tr>

<tr><td width="20%" valign="top">نوع البث الثاني</td><td width="1" valign="top">:</td><td><input type="text" name="n6" size="30" /></td></tr>

<tr><td valign="top"><?php print $lang_cp_content; ?></td><td valign="top">:</td><td><textarea rows="23" name="c6"></textarea></td></tr>

<tr><td width="20%" valign="top">نوع البث الثاني</td><td width="1" valign="top">:</td><td><input type="text" name="n7" size="30" /></td></tr>

<tr><td valign="top"><?php print $lang_cp_content; ?></td><td valign="top">:</td><td><textarea rows="23" name="c7"></textarea></td></tr>

<tr><td width="20%" valign="top">نوع البث الثاني</td><td width="1" valign="top">:</td><td><input type="text" name="n8" size="30" /></td></tr>

<tr><td valign="top"><?php print $lang_cp_content; ?></td><td valign="top">:</td><td><textarea rows="23" name="c8"></textarea></td></tr>



<tr><td></td><td></td><td><input value="<?php print $lang_cp_add; ?>" type="submit" /></td></tr>
</table>
</form>
