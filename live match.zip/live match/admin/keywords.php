<?php
include ("common.php");

if(isset($_GET['do'])) {
$op = mysql_query("UPDATE afm_maininfo SET keywords = '$_POST[keywords]'");
if($op) {
	print '<div class="greenbox">'.$lang_done.'</div>';
	print '<meta http-equiv="refresh" content="0;URL=success.php"> ';
}
}

?>

<table class="table_3" width="100%">
<tr><td class="table_3_title"><?php print $lang_cp_meta_keywords; ?></td></tr>
<tr>
<td>
<form action="?do" method="post">
<textarea name="keywords" cols="100%" rows="9"><?php print $cp_maininfo_row['keywords']; ?></textarea>
<br />
example : word1,word2,word2<br />
<input type="submit" value="<?php print $lang_update; ?>" />
</form>
</td>
</tr>
</table>
