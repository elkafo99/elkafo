<?php
session_start();
include ("../connect.php");

$cp_maininfo_query = mysql_query("SELECT * FROM afm_maininfo");
$cp_maininfo_row   = mysql_fetch_array($cp_maininfo_query);

$cp_control_query = mysql_query("SELECT * FROM afm_control");
$cp_control_row   = mysql_fetch_array($cp_control_query);

$lang_file = $cp_maininfo_row['defult_language'];

include ("../languages/$lang_file");

if(!$page == 'login') {
if($_SESSION['afm_cp'] == 'yes') { } else {
  print '<meta http-equiv="refresh" content="0;URL=login.php"> ';
exit;
}
}

$date = date("d/m/Y");

if($noheads !== 'yes') {
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<html dir="<?php echo $lang_direction; ?>">
<script src="../Ajax/jquery.js" type="text/javascript"></script>
<link rel="stylesheet" href="theme/css.css"  type="text/css">
<?php } ?>
<?php if($wysiwyg == 'yes') { ?>
<!-- TinyMCE -->
<script type="text/javascript" src="../includes/tinymce/tinymce.min.js"></script>
<script type="text/javascript">
	tinymce.init({
  selector: 'textarea',
  height: 300,
  plugins: [
    'advlist autolink lists link image charmap print preview anchor',
    'searchreplace visualblocks code fullscreen',
    'insertdatetime media table contextmenu paste code'
  ],
  toolbar: 'insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
  content_css: [
    '//fast.fonts.net/cssapi/e6dc9b99-64fe-4292-ad98-6974f93cd2a2.css',
    '//www.tinymce.com/css/codepen.min.css'
  ]
});


</script>
<!-- /TinyMCE -->

<?php }

function f_find_member($id,$col) {
	global $lang_male,$lang_female,$theme_file,$lang_guest,$autoactivate,$member_level,$lang_country;

	$mysql_f_find_member_query = mysql_query("SELECT * FROM afm_members WHERE id = '$id'");
	$mysql_f_find_member_row   = mysql_fetch_assoc($mysql_f_find_member_query);
	
	if ($col == username) {
		print '<a href="../member.php?id='.$id.'" target="_blank">';
		echo $mysql_f_find_member_row['username'];
		print '</a>';
		if($id == '0') {
			print $lang_guest;
		}
	}
}

?>
