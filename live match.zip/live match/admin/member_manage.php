<?php
$wysiwyg = 'yes';
include ("common.php");
?>

<?php
if(isset($_GET['final'])) {
$mysql_mmbr_edit_query = mysql_query("SELECT * FROM afm_members WHERE id = '$_GET[id]'");
$mysql_mmbr_edit_row   = mysql_fetch_array($mysql_mmbr_edit_query);
if($_POST['password'] == "") {
$password = $mysql_mmbr_edit_row['password'];
} else {
$password = md5($_POST['password']);
}
$op = mysql_query("UPDATE afm_members SET username = '$_POST[username]', password = '$password', email = '$_POST[email]' WHERE id = '$_GET[id]'");
if($op) {
	print '<div class="greenbox">'.$lang_done.'</div>';
	print '<meta http-equiv="refresh" content="0;URL=success.php"> ';
}
}
if(isset($_GET['id'])) {
$mysql_mmbr_edit_query = mysql_query("SELECT * FROM afm_members WHERE id = '$_GET[id]'");
$mysql_mmbr_edit_row   = mysql_fetch_array($mysql_mmbr_edit_query);
?>
<form action="?final&id=<?php echo $mysql_mmbr_edit_row['id']; ?>" method="post">
<table class="table_3" width="100%">
<tr><td class="table_3_title" colspan="3"><?php print $lang_cp_manage_members; ?> - <?php print $mysql_mmbr_edit_row['username']; ?></td></tr>
<tr>
<td></td>
</tr>
<tr><td width="20%"><?php print $lang_username; ?></td><td width="1">:</td><td><input type="text" value='<?php print $mysql_mmbr_edit_row['username']; ?>' name="username" /></td></tr>
<tr><td><?php print $lang_password; ?></td><td>:</td><td><input type="text" name="password" /></td></tr>
<tr><td><?php print $lang_your_email; ?></td><td>:</td><td><input name="email" type="text" value="<?php print $mysql_mmbr_edit_row['email']; ?>" /></td></tr>



<tr><td></td><td></td><td><input type="submit" value="<?php print $lang_update; ?>" /></td></tr>
</table>
</form>
<?php } ?>

<?php
if(isset($_GET['search'])) {
$cp_membermng_srch_query = mysql_query("SELECT id,username FROM afm_members WHERE username LIKE '%$_POST[username]%'");
?>
<table class="table_3" width="100%">
<tr><td class="table_3_title"><?php print $lang_cp_manage_members; ?> - <?php print $lang_members; ?></td></tr>
<tr>
<td align="center">
<?php while($row = mysql_fetch_array($cp_membermng_srch_query)) { ?>
<a href="?id=<?php echo $row['id']; ?>"><div><?php print $row['username']; ?></div></a>
<?php } ?>
</tr></tr></table>
<?php
}
?>
