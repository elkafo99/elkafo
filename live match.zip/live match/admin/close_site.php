<?php
$wysiwyg = 'yes';
include ("common.php");

if(isset($_GET['do'])) {
$op = mysql_query("UPDATE afm_maininfo SET close_yn = '$_POST[close_yn]', close_msg = '$_POST[close_msg]'");
if($op) {
	print '<div class="greenbox">'.$lang_done.'</div>';
	print '<meta http-equiv="refresh" content="0;URL=success.php"> ';
}
}

?>

<table class="table_3" width="100%">
<tr><td class="table_3_title" colspan="3"><?php print $lang_cp_close_site; ?></td></tr>

<form action="?do" method="post">
<tr><td width="20%"><?php print $lang_cp_close_site; ?></td><td width="1">:</td><td>
<select name="close_yn">
<option value="no" <?php if($cp_maininfo_row['close_yn'] == 'no') { print 'SELECTED'; } ?>><?php print $lang_no; ?></option>
<option value="yes" <?php if($cp_maininfo_row['close_yn'] == 'yes') { print 'SELECTED'; } ?>><?php print $lang_yes; ?></option>
</select>
</td></tr>
<tr><td><?php print $lang_message; ?></td><td>:</td><td>
<textarea name="close_msg"><?php print $cp_maininfo_row['close_msg']; ?></textarea>
</td></tr>
<tr><td></td><td></td><td><input type="submit" value="<?php print $lang_update; ?>" /></td></tr>
</form>

</table>
