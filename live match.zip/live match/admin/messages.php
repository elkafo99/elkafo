<?php

if(isset($_GET['del'])) {
include ("common.php");
$gid = $_GET['id'];
mysql_query("DELETE FROM afm_msgs WHERE id = '$gid'");
exit;
}
$wysiwyg = 'yes';
include ("common.php");
$cp_msgs_query = mysql_query("SELECT * FROM afm_msgs ORDER BY id DESC");
if(isset($_GET['add'])) {
$op = mysql_query("INSERT INTO afm_msgs(title, content, date) values ('$_POST[title]', '$_POST[content]', '$date')") or die (mysql_error());
if($op) {
	print '<div class="greenbox">'.$lang_done.'</div>';
	print '<meta http-equiv="refresh" content="0;URL=success.php"> ';
}
exit;
}

if(isset($_GET['edit'])) {
$gid = $_GET['id'];
$mysql_msgs_ed_query = mysql_query("SELECT * FROM afm_msgs WHERE id = '$gid'");
$mysql_msgs_ed_row   = mysql_fetch_array($mysql_msgs_ed_query);
?>
<form action="?doedit&id=<?php echo $gid; ?>" method="post" target="page">
<table class="table_3" width="100%">
<tr><td class="table_3_title" colspan="3"><?php print $lang_cp_index_msgs; ?> - <?php print $lang_edit; ?></td></tr>
<tr><td width="20%"><?php print $lang_title; ?></td><td width="1">:</td><td><input type="text" name="title" value="<?php print $mysql_msgs_ed_row['title']; ?>" size="30" /></td></tr>
<tr><td valign="top"><?php print $lang_cp_content; ?></td><td valign="top">:</td><td><textarea name="content"><?php print $mysql_msgs_ed_row['content']; ?></textarea></td></tr>
<tr><td></td><td></td><td><input type="submit" value="<?php print $lang_edit; ?>" /></td></tr>
</table>
</form>
<?php
exit;
}
if(isset($_GET['doedit'])) {
$op = mysql_query("UPDATE afm_msgs SET title = '$_POST[title]', content = '$_POST[content]' WHERE id = '$_GET[id]'");
if($op) {
	print '<div class="greenbox">'.$lang_done.'</div>';
	print '<meta http-equiv="refresh" content="0;URL=success.php"> ';
}
exit;
}
?>
<script>
$(document).ready(function() {
	$("#iframe").hide();
});
</script>
<form action="?add" method="post">
<table class="table_3" width="100%">
<tr><td class="table_3_title" colspan="3"><?php print $lang_cp_index_msgs; ?> - <?php print $lang_cp_add; ?></td></tr>
<tr><td width="20%"><?php print $lang_title; ?></td><td width="1">:</td><td><input type="text" name="title" size="30" /></td></tr>
<tr><td valign="top"><?php print $lang_cp_content; ?></td><td valign="top">:</td><td><textarea name="content"></textarea></td></tr>
<tr><td></td><td></td><td><input type="submit" value="<?php print $lang_cp_add; ?>" /></td></tr>
</table>
</form>


<table class="table_3" width="100%">
<tr><td class="table_3_title" colspan="2"><?php print $lang_cp_index_msgs; ?> - <?php print $lang_cp_manage; ?></td></tr>
<?php while($row = mysql_fetch_array($cp_msgs_query)) { ?>
<script>
$(document).ready(function() {
	$("#dl<?php echo $row['id']; ?>").click(function(){
		$("#tr<?php echo $row['id']; ?>").css("background","red");
		$("#tr<?php echo $row['id']; ?>").fadeOut("slow");
		$("#frame").load("?del&id=<?php echo $row['id']; ?>");
	});
	$("#ed<?php echo $row['id']; ?>").click(function(){
		$("#tr<?php echo $row['id']; ?>").css("background","yellow");
		$("#iframe").show();
		$("#iframe").attr("src","?edit&id=<?php echo $row['id']; ?>");
		$("#iframe").attr("height","300");
	});
});
</script>
<tr id="tr<?php echo $row['id']; ?>"><td width="80%"><?php print $row['title']; ?></td><td/><a href="#" id="ed<?php echo $row['id']; ?>"><?php print $lang_edit; ?></a> / <a href="#" id="dl<?php echo $row['id']; ?>"><?php print $lang_delete; ?></a></td></tr>
<?php } ?>
<span id="frame"></span>
</table>

<iframe frameborder="0" width="100%" height="0" id="iframe"></iframe>
