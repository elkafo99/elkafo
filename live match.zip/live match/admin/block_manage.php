<?php
if(isset($_GET['del'])) {
include ("common.php");
$gid = $_GET['id'];
mysql_query("DELETE FROM afm_blocks WHERE id = '$gid'");
exit;
}
if(isset($_GET['doedit'])) {
include ("common.php");
$op = mysql_query("UPDATE afm_blocks SET title = '$_POST[title]', content = '$_POST[content]',  page = '$_POST[page]', position = '$_POST[position]', file = '$_POST[file]', tarteeb = '$_POST[tarteeb]' WHERE id = '$_GET[id]'") or die(mysql_error());
if($op) {
	print '<div class="greenbox">'.$lang_done.'</div>';
	print '<meta http-equiv="refresh" content="0;URL=success.php"> ';
}
exit;
}

if(isset($_GET['edit'])) {
$wysiwyg = 'yes';
include ("common.php");
$gid = $_GET['id'];
$cp_edit_block_query = mysql_query("SELECT * FROM afm_blocks WHERE id = '$gid'");
$cp_edit_block_row   = mysql_fetch_array($cp_edit_block_query);
?>
<form action="?doedit&id=<?php echo $gid; ?>" method="post" target="page">
<table class="table_3" width="100%">
<tr><td class="table_3_title" colspan="3"><?php print $lang_cp_blocks; ?> - <?php print $lang_cp_add; ?></td></tr>
<tr><td width="20%"><?php print $lang_title; ?></td><td width="1">:</td><td><input type="text" size="30" name="title" value="<?php print $cp_edit_block_row['title']; ?>"/></td></tr>
<tr><td><?php print $lang_cp_page; ?></td><td>:</td><td>


<select name="page">
<option value="all" <?php if($cp_edit_block_row['page'] == 'all') { print 'SELECTED'; } ?>><?php print $lang_cp_all_pages; ?></option>
<option value="index" <?php if($cp_edit_block_row['page'] == 'index') { print 'SELECTED'; } ?>><?php print $lang_index; ?></option>
<option value="videos" <?php if($cp_edit_block_row['page'] == 'videos') { print 'SELECTED'; } ?>><?php print $lang_videos; ?></option>
 
</select>
</td></tr>



<tr><td><?php print $lang_cp_file; ?></td><td>:</td><td>
<select name="file">
<option value="no" <?php if($cp_edit_block_row['file'] == 'no') { print 'SELECTED'; } ?>><?php print $lang_cp_without_file; ?></option>
<?php
$handle = opendir('../blocks/');
while ($file = readdir($handle)) { ?>
<option value="<?php echo $file; ?>" <?php if($cp_edit_block_row['file'] == $file) { print 'SELECTED'; } ?>><?php print $file; ?></option>
<?php } ?>
</select>
</td></tr>
<tr><td><?php print $lang_cp_position; ?></td><td>:</td><td>
<select name="position">
<option value="2" <?php if($cp_edit_block_row['position'] == '2') { print 'SELECTED'; } ?>><?php print $lang_cp_left; ?></option>
<option value="1" <?php if($cp_edit_block_row['position'] == '1') { print 'SELECTED'; } ?>><?php print $lang_cp_right; ?></option>
<option value="3" <?php if($cp_edit_block_row['position'] == '3') { print 'SELECTED'; } ?>><?php print $lang_cp_top; ?> - <?php print $lang_cp_center; ?></option>
<option value="4" <?php if($cp_edit_block_row['position'] == '4') { print 'SELECTED'; } ?>><?php print $lang_cp_down; ?> - <?php print $lang_cp_center; ?></option>
</select>
</td></tr>
<tr><td><?php print $lang_order; ?></td><td>:</td><td><input type="text" name="tarteeb" size="3" value="<?php print $cp_edit_block_row['tarteeb']; ?>" /></td></tr>



<tr><td><?php print $lang_cp_content; ?></td><td>:</td><td><textarea name="content"><?php print $cp_edit_block_row['content']; ?></textarea></td></tr>


<tr><td></td><td></td><td><input type="submit" value="<?php print $lang_edit; ?>" /></td></tr>
</table>
</form>

<?php
exit;
}

$wysiwyg = 'yes';
include ("common.php");

if(isset($_GET['add'])) {
$op = mysql_query("INSERT INTO afm_blocks VALUES('', '$_POST[title]', '$_POST[content]', '$_POST[file]', '$_POST[position]', '$_POST[tarteeb]', '$_POST[page]')") or die(mysql_error());
if($op) {
	print '<div class="greenbox">'.$lang_done.'</div>';
	print '<meta http-equiv="refresh" content="0;URL=success.php"> ';
}
}

?>
<form action="?add" method="post">
<table class="table_3" width="100%">
<tr><td class="table_3_title" colspan="3"><?php print $lang_cp_blocks; ?> - <?php print $lang_cp_add; ?></td></tr>
<tr><td width="20%"><?php print $lang_title; ?></td><td width="1">:</td><td><input type="text" size="30" name="title" /></td></tr>
<tr><td><?php print $lang_cp_page; ?></td><td>:</td><td>
<select name="page">
<option value="all"><?php print $lang_cp_all_pages; ?></option>
<option value="index"><?php print $lang_index; ?></option>
 
 
 
 
<option value="videos"><?php print $lang_videos; ?></option>
 
 
 
 
</select>
</td></tr>

<tr><td><?php print $lang_cp_file; ?></td><td>:</td><td>
<select name="file">
<option value="no"><?php print $lang_cp_without_file; ?></option>
<?php
$handle = opendir('../blocks/');
while ($file = readdir($handle)) { ?>
<option value="<?php echo $file; ?>"><?php print $file; ?></option>
<?php } ?>
</select>
</td></tr>
<tr><td><?php print $lang_cp_position; ?></td><td>:</td><td>
<select name="position">
<option value="2"><?php print $lang_cp_left; ?></option>
<option value="1"><?php print $lang_cp_right; ?></option>
<option value="3"><?php print $lang_cp_top; ?> - <?php print $lang_cp_center; ?></option>
<option value="4"><?php print $lang_cp_down; ?> - <?php print $lang_cp_center; ?></option>
</select>
</td></tr>
<tr><td><?php print $lang_order; ?></td><td>:</td><td><input type="text" name="tarteeb" size="3" /></td></tr>


<tr><td><?php print $lang_cp_content; ?></td><td>:</td><td><textarea name="content"></textarea></td></tr>

<tr><td></td><td></td><td><input type="submit" value="<?php print $lang_cp_add; ?>" /></td></tr>
</table>
</form>




<table class="table_3" width="100%">
<tr class="table_3_title">
<td width="19"><img src="theme/images/block.png" height="18" width="18" /></td>
<td colspan="2"><?php print $lang_cp_manage_blocks; ?></td></tr>
<?php
$mysql_block_query = mysql_query("SELECT id,title FROM afm_blocks ORDER BY id DESC");
while($row = mysql_fetch_array($mysql_block_query)) {
?>
<script>
$(document).ready(function() {
	$("#dl<?php echo $row['id']; ?>").click(function(){
		$("#tr<?php echo $row['id']; ?>").css("background","red");
		$("#tr<?php echo $row['id']; ?>").fadeOut("slow");
		$("#frame").load("?del&id=<?php echo $row['id']; ?>");
	});
	$("#ed<?php echo $row['id']; ?>").click(function(){
		$("#tr<?php echo $row['id']; ?>").css("background","yellow");
		$("#iframe").attr("src","?edit&id=<?php print $row['id']; ?>");
		$("#iframe").attr("height","400");
	});
});
</script>
<tr id="tr<?php echo $row['id']; ?>">
<td width="19"><img src="theme/images/block.png" height="18" width="18" /></td>
<td width="80%"><?php print $row['title']; ?></td><td>
<a href="#edit" id="ed<?php echo $row['id']; ?>"><?php print $lang_edit; ?></a> / 
<a href="#delete" id="dl<?php echo $row['id']; ?>"><?php print $lang_delete; ?></a>
</td></tr>
<?php } ?>
</table>
<span id="frame"></span>
<iframe id="iframe" frameborder="0" width="100%" height="0"></iframe>

