<?php
if(isset($_GET['edit'])) {
	$wysiwyg = 'yes';
}
include ("common.php");
$cp_pages_query = mysql_query("SELECT * FROM afm_pages ORDER BY id DESC");

if(isset($_GET['del'])) {
mysql_query("DELETE FROM afm_pages WHERE id = '$_GET[id]'") or die(mysql_error());
exit;
}
if(isset($_GET['doedit'])) {
$gid = $_GET['id'];
$op = mysql_query("UPDATE afm_pages SET title = '$_POST[title]', content = '$_POST[content]', c2 = '$_POST[c2]', c3 = '$_POST[c3]', c4 = '$_POST[c4]', c5 = '$_POST[c5]', c6 = '$_POST[c6]', c7 = '$_POST[c7]', c8 = '$_POST[c8]', n1 = '$_POST[n1]', n2 = '$_POST[n2]', n3 = '$_POST[n3]', n4 = '$_POST[n4]', n5 = '$_POST[n5]', n6 = '$_POST[n6]', n7 = '$_POST[n7]', n8 = '$_POST[n8]' WHERE id = '$gid'");
if($op) {
	print '<div class="greenbox">'.$lang_done.'</div>';
	print '<meta http-equiv="refresh" content="0;URL=success.php"> ';
}
}
if(isset($_GET['edit'])) {
$wysiwyg = 'yes';
$mysql_editpg78_query = mysql_query("SELECT * FROM afm_pages WHERE id = '$_GET[id]'");
$mysql_editpg78_row  = mysql_fetch_array($mysql_editpg78_query);
?>
<form action="?doedit&id=<?php echo $_GET['id']; ?>" method="post" target="page">
<table class="table_3" width="100%">
<tr><td class="table_3_title" colspan="3"><?php print $lang_pages; ?> - <?php print $lang_edit; ?></td></tr>


<tr><td width="20%"><?php print $lang_title; ?></td><td width="1">:</td><td><input name="title" type="text" size="30" value="<?php print $mysql_editpg78_row['title']; ?>" /></td></tr>




<tr><td width="20%">نوع البث الاول</td><td width="1">:</td><td><input name="n1" type="text" size="30" value="<?php print $mysql_editpg78_row['n1']; ?>" /></td></tr>

<tr><td width="20%"><?php print $lang_cp_content; ?></td><td width="1">:</td><td>
<textarea name="content"><?php print $mysql_editpg78_row['content']; ?></textarea>
</td></tr>



<tr><td width="20%">نوع البث الثاني</td><td width="1">:</td><td><input name="n2" type="text" size="30" value="<?php print $mysql_editpg78_row['n2']; ?>" /></td></tr>

<tr><td width="20%"><?php print $lang_cp_content; ?></td><td width="1">:</td><td>
<textarea name="c2"><?php print $mysql_editpg78_row['c2']; ?></textarea>
</td></tr>



<tr><td width="20%">نوع البث الثالث</td><td width="1">:</td><td><input name="n3" type="text" size="30" value="<?php print $mysql_editpg78_row['n3']; ?>" /></td></tr>

<tr><td width="20%"><?php print $lang_cp_content; ?></td><td width="1">:</td><td>
<textarea name="c3"><?php print $mysql_editpg78_row['c3']; ?></textarea>
</td></tr>



<tr><td width="20%">نوع البث الرابع</td><td width="1">:</td><td><input name="n4" type="text" size="30" value="<?php print $mysql_editpg78_row['n4']; ?>" /></td></tr>

<tr><td width="20%"><?php print $lang_cp_content; ?></td><td width="1">:</td><td>
<textarea name="c4"><?php print $mysql_editpg78_row['c4']; ?></textarea>
</td></tr>



<tr><td width="20%">نوع البث الخامس</td><td width="1">:</td><td><input name="n5" type="text" size="30" value="<?php print $mysql_editpg78_row['n5']; ?>" /></td></tr>

<tr><td width="20%"><?php print $lang_cp_content; ?></td><td width="1">:</td><td>
<textarea name="c5"><?php print $mysql_editpg78_row['c5']; ?></textarea>
</td></tr>



<tr><td width="20%">نوع البث السادس</td><td width="1">:</td><td><input name="n6" type="text" size="30" value="<?php print $mysql_editpg78_row['n6']; ?>" /></td></tr>

<tr><td width="20%"><?php print $lang_cp_content; ?></td><td width="1">:</td><td>
<textarea name="c6"><?php print $mysql_editpg78_row['c6']; ?></textarea>
</td></tr>



<tr><td width="20%">نوع البث السابع</td><td width="1">:</td><td><input name="n7" type="text" size="30" value="<?php print $mysql_editpg78_row['n7']; ?>" /></td></tr>

<tr><td width="20%"><?php print $lang_cp_content; ?></td><td width="1">:</td><td>
<textarea name="c7"><?php print $mysql_editpg78_row['c7']; ?></textarea>
</td></tr>


<tr><td width="20%">نوع البث الثامن</td><td width="1">:</td><td><input name="n8" type="text" size="30" value="<?php print $mysql_editpg78_row['n8']; ?>" /></td></tr>

<tr><td width="20%"><?php print $lang_cp_content; ?></td><td width="1">:</td><td>
<textarea name="c8"><?php print $mysql_editpg78_row['c8']; ?></textarea>
</td></tr>



<tr><td></td><td></td><td><input type="submit" value="<?php print $lang_edit; ?>" /></td></tr>
</table>
</form>
<?php
exit;
}

?>
<table class="table_3" width="100%">
<tr><td class="table_3_title" colspan="2"><?php print $lang_pages; ?> - <?php print $lang_cp_manage; ?></td></tr>
<?php while($row = mysql_fetch_array($cp_pages_query)) { ?>
<script>
$(document).ready(function() {
	$("#dl<?php echo $row['id']; ?>").click(function(){
		$("#tr<?php echo $row['id']; ?>").css("background","red");
		$("#tr<?php echo $row['id']; ?>").fadeOut("slow");
		$("#tr2<?php echo $row['id']; ?>").css("background","red");
		$("#tr2<?php echo $row['id']; ?>").fadeOut("slow");
		$("#frame").load("?del&id=<?php echo $row['id']; ?>");
	});
	$("#ed<?php echo $row['id']; ?>").click(function(){
		$("#tr<?php echo $row['id']; ?>").css("background","yellow");
		$("#iframe").show();
		$("#iframe").attr("src","?edit&id=<?php echo $row['id']; ?>");
		$("#iframe").attr("height","100%");
	});
});
</script>
<tr id="tr<?php echo $row['id']; ?>"><td width="80%"><?php print $row['title']; ?></td><td>
<a id="ed<?php echo $row['id']; ?>" href="#"><?php print $lang_edit; ?></a> / <a id="dl<?php echo $row['id']; ?>" href="#"><?php print $lang_delete; ?></a>
</td></tr>
<tr id="tr2<?php echo $row['id']; ?>"><td colspan="2"><?php print $lang_url; ?> : <a href="<?php print $cp_maininfo_row['address']; ?>?p=<?php echo $row['id']; ?>" target="_blank"><?php print $cp_maininfo_row['address']; ?>/?p=<?php echo $row['id']; ?></a></td></tr>
<?php } ?>
</table>
<span id="frame"></span>
<iframe frameborder="0" width="100%" height="0" id="iframe"></iframe>
