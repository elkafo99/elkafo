<?php
session_start();

$_SESSION['afm_cp'] = 'no';

print '<meta http-equiv="refresh" content="0;URL=../index.php"> ';

?>
