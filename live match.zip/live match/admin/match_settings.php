<?php
include ("common.php");
$cp_topics_settings_query = mysql_query("SELECT * FROM afm_topics_settings");
$cp_topics_settings_row   = mysql_fetch_array($cp_topics_settings_query);

if(isset($_GET['do'])) {
$ppg_pre = $_POST['topics_per_pg'];
if(!is_numeric($ppg_pre) OR $ppg_pre == "0") {
$ppg = "1";
} else {
$ppg = $_POST['topics_per_pg'];
}


$op = mysql_query("UPDATE afm_topics_settings SET fast_stats = '$_POST[fast_stats]', send_topic = '$_POST[send_topic]', show_sig = '$_POST[show_sig]', topics_per_pg = '$ppg', catpg_clms = '$_POST[catpg_clms]'");
if($op) {
	print '<div class="greenbox">'.$lang_done.'</div>';
	print '<meta http-equiv="refresh" content="0;URL=success.php"> ';
}
}


?>

<form action="?do" method="post">
<table class="table_3" width="100%">
<tr><td class="table_3_title" colspan="3"><?php print $lang_topics; ?> - <?php print $lang_cp_settings; ?></td></tr>
<tr><td width="30%"><?php print $lang_fast_statics; ?></td><td width="1">:</td><td>
<select name="fast_stats">
<option value="yes" <?php if($cp_topics_settings_row['fast_stats'] == 'yes') { print'SELECTED'; } ?>><?php print $lang_yes; ?></option>
<option value="no" <?php if($cp_topics_settings_row['fast_stats'] == 'no') { print'SELECTED'; } ?>><?php print $lang_no; ?></option>
</select>
</td></tr>

<tr><td><?php print $lang_cp_allow_users_send; ?> : <?php print $lang_topics; ?></td><td>:</td><td>
<select name="send_topic">
<option value="yes" <?php if($cp_topics_settings_row['send_topic'] == 'yes') { print'SELECTED'; } ?>><?php print $lang_yes; ?></option>
<option value="no" <?php if($cp_topics_settings_row['send_topic'] == 'no') { print'SELECTED'; } ?>><?php print $lang_no; ?></option>
</select>
</td></tr>

<tr><td><?php print $lang_cp_results_per_pg; ?></td><td>:</td><td><input name="topics_per_pg" size="5" value="<?php print $cp_topics_settings_row['topics_per_pg']; ?>" /></td></tr>
<tr><td><?php print $lang_cp_show_mem_signs; ?></td><td>:</td><td>
<select name="show_sig">
<option value="yes" <?php if($cp_topics_settings_row['show_sig'] == 'yes') { print'SELECTED'; } ?>><?php print $lang_yes; ?></option>
<option value="no" <?php if($cp_topics_settings_row['show_sig'] == 'no') { print'SELECTED'; } ?>><?php print $lang_no; ?></option>
</select>
</td></tr>
<tr><td><?php print $lang_cp_colums; ?></td><td>:</td><td>
<select name="catpg_clms">
<option value="1" <?php if($cp_topics_settings_row['catpg_clms'] == '1') { print'SELECTED'; } ?>>1</option>
<option value="2" <?php if($cp_topics_settings_row['catpg_clms'] == '2') { print'SELECTED'; } ?>>2</option>
</select>
</td></tr>
<tr><td></td><td></td><td><input type="submit" value="<?php print $lang_update; ?>" />
</table>
</form>
