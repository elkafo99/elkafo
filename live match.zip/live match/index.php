<?php
if(isset($_GET['p'])) {
	$page = 'pages';
} else {
	$page = "index";
}
include ("header.php");
if(isset($_GET['p'])) {
include ("includes/window_top.php");
$gp = $_GET['p'];
$mysql_pages_pg_query = mysql_query("SELECT * from afm_pages WHERE url = '$gp'");
$mysql_pages_pg_row   = mysql_fetch_array($mysql_pages_pg_query);





?>







<title><?php print $title; ?> - <?php print $mysql_pages_pg_row['title']; ?></title>
<meta name="keywords" content="<?php print $mysql_pages_pg_row['title']; ?>">

<link rel="stylesheet" href="taps.css">
<style>
.city {display:none;}
</style>







<div class="w3-container">
<h2><?php print $mysql_pages_pg_row['title']; ?></h2>
 
</div>

<ul class="w3-navbar w3-black">
  <li><a href="#" onclick="openCity('<?php print $mysql_pages_pg_row['n1']; ?>')"><?php print $mysql_pages_pg_row['n1']; ?></a></li>
<?  if ($mysql_pages_pg_row['n2'] !== "") { ?>
  <li><a href="#" onclick="openCity('<?php print $mysql_pages_pg_row['n2']; ?>')"><?php print $mysql_pages_pg_row['n2']; ?></a></li>
<? } ?>
<?  if ($mysql_pages_pg_row['n3'] !== "") { ?>
  <li><a href="#" onclick="openCity('<?php print $mysql_pages_pg_row['n3']; ?>')"><?php print $mysql_pages_pg_row['n3']; ?></a></li>
<? } ?>
<?  if ($mysql_pages_pg_row['n4'] !== "") { ?>
  <li><a href="#" onclick="openCity('<?php print $mysql_pages_pg_row['n4']; ?>')"><?php print $mysql_pages_pg_row['n4']; ?></a></li>
<? } ?>
<?  if ($mysql_pages_pg_row['n5'] !== "") { ?>
  <li><a href="#" onclick="openCity('<?php print $mysql_pages_pg_row['n5']; ?>')"><?php print $mysql_pages_pg_row['n5']; ?></a></li>
<? } ?>
<?  if ($mysql_pages_pg_row['n6'] !== "") { ?>
  <li><a href="#" onclick="openCity('<?php print $mysql_pages_pg_row['n6']; ?>')"><?php print $mysql_pages_pg_row['n6']; ?></a></li>
<? } ?>
<?  if ($mysql_pages_pg_row['n7'] !== "") { ?>
  <li><a href="#" onclick="openCity('<?php print $mysql_pages_pg_row['n7']; ?>')"><?php print $mysql_pages_pg_row['n7']; ?></a></li>
<? } ?>
<?  if ($mysql_pages_pg_row['n8'] !== "") { ?>
  <li><a href="#" onclick="openCity('<?php print $mysql_pages_pg_row['n8']; ?>')"><?php print $mysql_pages_pg_row['n8']; ?></a></li>
<? } ?>


</ul>

<div id="<?php print $mysql_pages_pg_row['n1']; ?>" class="w3-container city">
<br>
  <p><?php print $mysql_pages_pg_row['content']; ?></p>
</div>

<?  if ($mysql_pages_pg_row['n2'] !== "") { ?>
<div id="<?php print $mysql_pages_pg_row['n2']; ?>" class="w3-container city">
<br>
  <p><?php print $mysql_pages_pg_row['c2']; ?></p> 
</div>

<? } ?>
<?  if ($mysql_pages_pg_row['n3'] !== "") { ?>
<div id="<?php print $mysql_pages_pg_row['n3']; ?>" class="w3-container city">
<br>
  <p><?php print $mysql_pages_pg_row['c3']; ?></p> 
</div>

<? } ?>
<?  if ($mysql_pages_pg_row['n4'] !== "") { ?>

<div id="<?php print $mysql_pages_pg_row['n4']; ?>" class="w3-container city">
<br>
  <p><?php print $mysql_pages_pg_row['c4']; ?></p> 
</div>

<? } ?>
<?  if ($mysql_pages_pg_row['n5'] !== "") { ?>

<div id="<?php print $mysql_pages_pg_row['n5']; ?>" class="w3-container city">
<br>
  <p><?php print $mysql_pages_pg_row['c5']; ?></p> 
</div>

<? } ?>
<?  if ($mysql_pages_pg_row['n6'] !== "") { ?>

<div id="<?php print $mysql_pages_pg_row['n6']; ?>" class="w3-container city">
<br>
  <p><?php print $mysql_pages_pg_row['c6']; ?></p> 
</div>

<? } ?>
<?  if ($mysql_pages_pg_row['n7'] !== "") { ?>


<div id="<?php print $mysql_pages_pg_row['n7']; ?>" class="w3-container city">
<br>
  <p><?php print $mysql_pages_pg_row['c7']; ?></p> 
</div>

<? } ?>
<?  if ($mysql_pages_pg_row['n8'] !== "") { ?>


<div id="<?php print $mysql_pages_pg_row['n8']; ?>" class="w3-container city">
<br>

  <p><?php print $mysql_pages_pg_row['c8']; ?></p> 
</div>
<? } ?>

<script>
openCity("<?php print $mysql_pages_pg_row['n1']; ?>")
function openCity(cityName) {
    var i;
    var x = document.getElementsByClassName("city");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    document.getElementById(cityName).style.display = "block";  
}
</script>



<?php

include ("includes/window_down.php");
} else {
?>
<title><?php print $title; ?></title>
<?php
 
}
include ("footer.php");
?>
