<?php

$theme_settings['text_position']         = "center"    ;
$theme_settings['input1_width']          = "20"        ;
$theme_settings['texteditor']            = "2"         ; //texteditor theme 1=normal , 2=blue , 3=silver

?>
