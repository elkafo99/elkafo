<?php


$d1 = date("d/m/Y");


$mysql_blockltstnews1clmcntr_query = mysql_query("SELECT * FROM afm_topics_topics WHERE date = '$d1' ");





if (mysql_num_rows($mysql_blockltstnews1clmcntr_query) !== 0) { 




while($row = mysql_fetch_array($mysql_blockltstnews1clmcntr_query)) {


$datee =  $row['date'];

$pieces = explode("/", $datee);





?>







<div class="tab" data-show="today">
<li class="coraliv-fixtures" id="match_1785">




<?php
if($row['live'] == "yes") {
?>
<div class="live">

<img alt="مباشر" src="live.gif"/>
</div>
<?php
}

?>




 
<div class="center-c">
<div class="tems">
<div class="team1">
<div style="float: right;" class="command_info">
<div class="score1"><?php echo $row['res1']; ?></div>
<div class="team-logo">

<?php
if($row['image'] !== "") {
?>

<img alt="<?php print $row['title']; ?>" src="<?php echo $row['image']; ?>"/>
<?php
}
else {

?>

<img alt="<?php print $row['title']; ?>" src="https://upload.wikimedia.org/wikipedia/commons/a/ac/No_image_available.svg"/>

<?php
}

?>

</div>
</div>
<div class="team-name"><span><?php print $row['title']; ?></span></div>
</div>
<div class="center-vs"></div>
<div class="team2">
<div class="team-name"><span><?php print $row['title2']; ?></span></div>
<div style="float: left;" class="command_info">
<div class="team-logo2">


<?php
if($row['image2'] !== "") {
?>

<img alt="<?php print $row['title2']; ?>" src="<?php echo $row['image2']; ?>"/>
<?php
}
else {

?>

<img alt="<?php print $row['title2']; ?>" src="https://upload.wikimedia.org/wikipedia/commons/a/ac/No_image_available.svg"/>

<?php
}

?>
</div>
<div class="score2"><?php echo $row['res2']; ?></div>
</div>
</div>
<div class="info-live">
<div class="coralive-time"><span> الساعة <?php echo $row['time']; ?></span></div>
<div class="coralive-comm"><span>تعليق : <?php echo $row['com']; ?> </span></div>
</div>
</div>
</div>





<?php $pgid = $row['page']; ?>

 

<?php

$mysql_topics21_stpg_query = mysql_query("SELECT * FROM afm_pages WHERE id = '$pgid'");

 while($row = mysql_fetch_array($mysql_topics21_stpg_query)) { ?>

<div onclick="location.href=?p=<?php echo $row['url']; ?>';" class='mach-live'>


<a class='show-mach' href=?p=<?php echo $row['url']; ?>>

شـــاهـــد الــمـبـاراة
</a>

<?php } ?>
</div>
</li>
</div>










<?php
}
  }else{




?>


<div class="tab">
<li class="coraliv-fixtures">
<div style="text-align: center;line-height: 95px;height: 95px;margin: 0px auto;width: 100%;">
لا يوجد مباريات  </div>
</li>
</div>



<?   } ?>