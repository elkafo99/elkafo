<style>
body {
	margin : 0;
}
</style>
<?php
function secure($string) { $string = strip_tags($string); $string = htmlspecialchars($string); $string = trim($string); $string = stripslashes($string); $string = mysql_real_escape_string($string); return $string; }  

include ("../connect.php");
$gh = secure($_GET['h']);
$gw = secure($_GET['w']);
$gid = secure($_GET['id']);
$mysql_query = mysql_query("SELECT id,avatar FROM afm_members WHERE id = '$gid'");
$mysql_total = mysql_num_rows($mysql_query);
$mysql_row   = mysql_fetch_array($mysql_query);

if($mysql_total == 1) {
	if($mysql_row['avatar'] == "") {
	print '<img src="../images/no_avatar.jpg"  height="'.$gh.'" width="'.$gw.'" />';
	} else {
	print '<img src="'.$mysql_row['avatar'].'" height="'.$gh.'" width="'.$gw.'" />';
	}
} else {
	print '<img src="../images/no_avatar.jpg"  height="'.$gh.'" width="'.$gw.'" />';
}
?>
