<?php
header('Content-Type: image/jpeg');
$afm465127687 = '5849841984';
include ("../connect.php");

$gid = $_GET['id'];
$query = mysql_query("SELECT id,image FROM afm_videos_videos WHERE id = '$gid'");
$row = mysql_fetch_array($query);

if($row['image'] == "") {
readfile("../images/no_vid_img.png");
} else {
print $row['image'];
}

mysql_close();
?>
