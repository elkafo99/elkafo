﻿tinyMCE.addI18n({ar:{
common:{
edit_confirm:"هل تريد استخدام الوضع المرئى للنص؟",
apply:"تطبيق",
insert:"إدراج",
update:"تحديث",
cancel:"إلغاء",
close:"إغلاق",
browse:"إستعراض",
class_name:"التصنيف",
not_set:"-- لم يتم تعيين --",
clipboard_msg:"نسخ/قص/لصق ليس مفعل مع متصفح الفايرفوكس.\nهل تريد المزيد من المعلومات عن ذلك؟",
clipboard_no_support:"حاليا ليس مدعم من المتصفح الخاص بك ، استخدم اختصارات لوحة المفاتيح بدلا من ذلك.",
popup_blocked:"عذرا, ولكن لاحظنا أن مانع لديك النوافذ المنبثقة ، قامت بتعطيل النافذة التي توفر وظائف التطبيق. سوف تحتاج إلى تعطيل حظر المنبثقة على هذا الموقع من أجل الاستفادة الكاملة من هذه الأداة.",
invalid_data:"خطأ : أدخلت قيم غير صحيحة ، وهذه محددة باللون الاحمر.",
more_colors:"المزيد من الألوان"
},
contextmenu:{
align:"المحاذاة",
left:"لليسار",
center:"للوسط",
right:"لليمين",
full:"ضبط"
},
insertdatetime:{
date_fmt:"%Y-%m-%d",
time_fmt:"%H:%M:%S",
insertdate_desc:"إدراج التاريخ",
inserttime_desc:"إدراج الوقت",
months_long:"يناير,فبراير,مارس,أبريل,مايو,يونيه,يوليو,أغسطس,سبتمبر,أكتوبر,نوفمبر,ديسمبر",
months_short:"يناير,فبراير,مارس,أبريل,مايو,يونيه,يوليو,أغسطس,سبتمبر,أكتوبر,نوفمبر,ديسمبر",
day_long:"الأحد,الأثنين,الثلاثاء,الأربعاء,الخميس,الجمعة,السبت,الأحد",
day_short:"الأحد,الأثنين,الثلاثاء,الأربعاء,الخميس,الجمعة,السبت,الأحد"
},
print:{
print_desc:"طباعة"
},
preview:{
preview_desc:"معاينة"
},
directionality:{
ltr_desc:"الإتجاه من اليسار لليمين",
rtl_desc:"الإتجاه من اليمين لليسار"
},
layer:{
insertlayer_desc:"إدراج طبقة جديدة",
forward_desc:"إحضار للأمام",
backward_desc:"إحضار للخلف",
absolute_desc:"تبديل الموقع إلى مطلق",
content:"<p dir='rtl'>طبقة جديدة ...</p>"
},
save:{
save_desc:"حفظ",
cancel_desc:"إلغاء كل التغيرات"
},
nonbreaking:{
nonbreaking_desc:"إدراج مسافة"
},
iespell:{
iespell_desc:"تفعيل المدقق الإملائى",
download:"المدقق الإملائى غير مفعل. هل تريد تنزيله الأن؟"
},
advhr:{
advhr_desc:"خط فاصل"
},
emotions:{
emotions_desc:"إبتسامات"
},
searchreplace:{
search_desc:"بحث",
replace_desc:"بحث/إستبدال"
},
advimage:{
image_desc:"إدراج/تعديل صورة"
},
advlink:{
link_desc:"إدراج/تعديل رابط"
},
xhtmlxtras:{
cite_desc:"إقتباس",
abbr_desc:"إختصار",
acronym_desc:"الإسم المختصر",
del_desc:"شطب",
ins_desc:"الإدراج",
attribs_desc:"إدراج/تعديل السمة"
},
style:{
desc:"تعديل نمط CSS"
},
paste:{
paste_text_desc:"لصق كنص",
paste_word_desc:"لصق من Word",
selectall_desc:"تحديد الكل"
},
paste_dlg:{
text_title:"إستخدم CTRL+V لإلصاق النص فى النافذة.",
text_linebreaks:"Keep linebreaks",
word_title:"إستخدم CTRL+V لإلصاق النص فى النافذة."
},
table:{
desc:"إدراج جدول جديد",
row_before_desc:"إدراج صفوف لأعلى",
row_after_desc:"إدراج صفوف لأسفل",
delete_row_desc:"حذف صف",
col_before_desc:"إدراج عمود لليسار",
col_after_desc:"إدراج عمود لليمين",
delete_col_desc:"مسح عمود",
split_cells_desc:"تقسيم الخلايا",
merge_cells_desc:"دمج الخلايا",
row_desc:"خصائص الصف",
cell_desc:"خصائص الخلية",
props_desc:"خصائص الجدول",
paste_row_before_desc:"إلصاق صف لأعلى",
paste_row_after_desc:"إلصاق صف لأسفل",
cut_row_desc:"قص صف",
copy_row_desc:"نسخ صف",
del:"حذف الجدول",
row:"صف",
col:"عمود",
cell:"خلية"
},
autosave:{
unload_msg:"جميع التعديلات التى قمت بها سوف تلغى اذا انتقلت من الصفحة.",
restore_content: "إستعادة الألية للمحتوى",
warning_message: "إذا لم تحفظ المحتوى سوف تلغى جميع التعديلات التى قمت بها.\n\nهل أنت متأكد ان تريد إستعادة التعديلات؟"
},
fullscreen:{
desc:"ملء الشاشة"
},
media:{
desc:"إدراج / تعديل ملف ميديا",
edit:"تعديل ملف ميديا"
},
fullpage:{
desc:"خصائص المستند"
},
template:{
desc:"إدراج قوالب جاهزة"
},
visualchars:{
desc:"تشغيل/إطفاء"
},
spellchecker:{
desc:"تثبيت المدقق الإملائى",
menu:"إعدادات المدقق الإملائى",
ignore_word:"تجاهل الكلمة",
ignore_words:"تجاهل الكل",
langs:"اللغات",
wait:"من فضلك انتظر ...",
sug:"إقتراحات",
no_sug:"لا توجد أى إقتراحات",
no_mpell:"لم يتم العثور على أى أخطاء"
},
pagebreak:{
desc:"إدراج فاصل الصفحات."
},
advlist : {
	types : 'النوع',
	def : 'إفتراضى',
	lower_alpha : "حروف إنجليزية صغيرة",
	lower_greek : "أرقام",
	lower_roman : "أرقام لاتينية صغيرة",
	upper_alpha : "حروف إنجليزية كبيرة",
	upper_roman : "أرقام لاتينية كبيرة",
	circle : "دائرى مغلق",
	disc : "دائرى مفتوح",
	square : "مربع"
}
}});
