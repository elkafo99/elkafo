﻿tinyMCE.addI18n('en.paste_dlg',{
text_title:"إستخدم CTRL+V لإلصاق النص فى النافذة.",
text_linebreaks:"Keep linebreaks",
word_title:"إستخدم CTRL+V لإلصاق النص فى النافذة."
});