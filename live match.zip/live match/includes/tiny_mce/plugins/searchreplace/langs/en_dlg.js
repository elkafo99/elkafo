﻿tinyMCE.addI18n('en.searchreplace_dlg',{
searchnext_desc:"إبحث مرة أخرى",
notfound:"إنتهى البحث.لم يتم إيجاد أى نص.",
search_title:"بحث",
replace_title:"بحث/إستبدال",
allreplaced:"تم إستبدال الكل.",
findwhat:"ابحث عن",
replacewith:"إستبدل بـ",
direction:"الإتجاه",
up:"أعلى",
down:"أسفل",
mcase:"طابق الحالة",
findnext:"أبحث",
replace:"إستبدل",
replaceall:"إستبدل الكل"
});