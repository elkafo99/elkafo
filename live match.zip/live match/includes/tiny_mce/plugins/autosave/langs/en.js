﻿tinyMCE.addI18n('en.autosave',{
restore_content: "استعادة الحفظ",
warning_message: "إذا لم تحفظ المحتوى سوف تلغى جميع التعديلات التى قمت بها.\n\nهل أنت متأكد ان تريد إستعادة التعديلات؟"
});