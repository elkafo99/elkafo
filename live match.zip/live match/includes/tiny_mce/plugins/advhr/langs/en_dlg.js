﻿tinyMCE.addI18n('en.advhr_dlg',{
width:"العرض",
size:"الإرتقاع",
noshade:"بدون ظل"
});