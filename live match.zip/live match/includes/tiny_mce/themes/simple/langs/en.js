﻿tinyMCE.addI18n('en.simple',{
bold_desc:"عريض (Ctrl+B)",
italic_desc:"مائل (Ctrl+I)",
underline_desc:"تسطير (Ctrl+U)",
striketrough_desc:"شطب",
bullist_desc:"تعداد نقطى",
numlist_desc:"تعداد رقمى",
undo_desc:"تراجع (Ctrl+Z)",
redo_desc:"إعادة (Ctrl+Y)",
cleanup_desc:"Cleanup messy code"
});