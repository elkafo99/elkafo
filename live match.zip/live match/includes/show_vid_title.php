<?php
include ("../connect.php");
$gid = $_GET['id'];
$mysql_show_vid_title_php_query = mysql_query("SELECT id,title FROM afm_videos_videos WHERE id = '$gid'");
$mysql_show_vid_title_php_row   = mysql_fetch_array($mysql_show_vid_title_php_query);

print $mysql_show_vid_title_php_row['title'];

?>
