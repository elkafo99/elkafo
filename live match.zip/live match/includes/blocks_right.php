<?php

$mysql_blocks_ri_query = mysql_query("SELECT * FROM afm_blocks WHERE position = '1' AND page = 'all' OR position = '1' AND page = '$page' ORDER BY tarteeb DESC");

while($block = mysql_fetch_assoc($mysql_blocks_ri_query)) {
	if (file_exists("themes/$theme_file/s_block.html")) {
		include ("themes/$theme_file/s_block.html");
	} else {
?>
<table width="160" cellspacing="0" cellpanding="0" border="1">
<tr>
<td align="center">
<?php echo $block['title']; ?>
</td>
<tr>
<td>
<?php f_block_content($block['id']) ?>
</td>
</tr>
</table>
<?php
	}
}

?>
