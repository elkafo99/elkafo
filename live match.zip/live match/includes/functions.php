<?php
function secure($string,$level) {
	if($level == 'high') {
	$string = strip_tags($string);
	$string = htmlspecialchars($string);
	$string = trim($string);
	$string = stripslashes($string);
	}
	$string = $string;
	return $string;
}  
function share_btn($page,$method) {
	global $lang_shortcut,$lang_share_more,$theme_file,$lang_share_facebook,$lang_share_twitter,$lang_share_google,$lang_share_email,$lang_share_bookmark;
	?>
		<!-- AddThis Button BEGIN -->
		<script type="text/javascript">
		var addthis_config = {
			 ui_language: "<?=$lang_shortcut; ?>"
		}
		</script>
		<div class="addthis_toolbox addthis_default_style" dir="rtl">
		<a href="http://www.addthis.com/bookmark.php?v=250" class="addthis_button_expanded" title="<?=$lang_share_more; ?>"></a>
		<a class="addthis_button_facebook" title="<?=$lang_share_facebook; ?>"><img src="themes/<?=$theme_file; ?>/icons/share/facebook.png" /></a>
		<a class="addthis_button_twitter" title="<?=$lang_share_twitter; ?>"><img src="themes/<?=$theme_file; ?>/icons/share/twitter.png" /></a>
		<a class="addthis_button_google" title="<?=$lang_share_google; ?>"><img src="themes/<?=$theme_file; ?>/icons/share/google.png" /></a>
		<a class="addthis_button_email" title="<?=$lang_share_email; ?>"><img src="themes/<?=$theme_file; ?>/icons/share/email.png" /></a>
		<a class="addthis_button_favorites" title="<?=$lang_share_bookmark; ?>"></a>

		</div>
		<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js"></script>

		<!-- AddThis Button END -->
	<?php
}
function f_mysql_error($num) {
	if ($num == 1) {
		print 'afm failed in connecting to the database <span style="color:#ff0000;">[ Error:001 ]</span>  <br/><span style="color:#ff0000;" dir="ltr"> [ خطأ:001 ]</span> فشل في الإتصال بقاعدة البيانات afm  ';
	}
}

function f_block_content($id) {
	global $lang_login , $lang_password , $lang_your_email , $lang_remember_me , $lang_register , $member , $lang_logout , $lang_member_control_panel ,$lang_welcome, $theme_file;

	$mysql_f_block_content_query 
= mysql_query("SELECT * FROM afm_blocks WHERE id = $id");
	$mysql_f_block_content_row   = mysql_fetch_assoc($mysql_f_block_content_query);
	
	echo $mysql_f_block_content_row['content'];
	
	$f_block_content_file = $mysql_f_block_content_row['file'];
	
	if ($f_block_content_file == no) { } else {
	@include("blocks/$f_block_content_file");	
	}

}

function f_window($a) {

	global $theme_file;

	if ($a == top) {
		@include ("themes/$theme_file/window_top.html");
	} elseif ($a == down) {
		@include ("themes/$theme_file/window_down.html");
	}
}

function image($url,$gradual,$h,$w,$altr,$thumb) {
	global $ajax;
if($thumb == "") {
$theurl = $url;
} else {
$theurl = $thumb;
}
	if ($ajax == 'on') {
?>

<center>
<a href="<?php echo $url; ?>" class="thickbox" title="<?php print $altr; ?>"><img alt="<?php print $altr; ?>" src="<?php echo $theurl; ?>" height="<?php echo $h; ?>" width="<?php echo $w; ?>" class="gradualfader" /></a>

<?php if($gradual == 'yes') { ?><script>
gradualFader.init()
</script><?php } ?>
</center>



<?php
	} else {
print '<center>';
$imggg = '<img src="'.$url.'" height="'.$h.'" width="'.$w.'" border="0"/>';
		?>
<SCRIPT LANGUAGE="JavaScript">

function popUp(URL) {
day = new Date();
id = day.getTime();
eval("page" + id + " = window.open(URL, '" + id + "', 'toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=1,width=600,height=450,left = 500,top = 134');");
}

</script>
<A HREF="javascript:popUp('<?php echo $url; ?>')"><?php echo $imggg; ?></A>
		<?php
print '</center>';
	}
}

function frame($text,$url,$altr) {
	global $ajax;
	if ($ajax == 'on') {
?>
<a href="<?php echo $url; ?>
<?php if(eregi('&',$url)) { ?>
&KeepThis=true&TB_iframe=true&height=400&width=500
<?php } else { ?>
?KeepThis=true&TB_iframe=true&height=400&width=500
<?php } ?>
" title="<?php echo $altr; ?>" class="thickbox"><?php echo $text; ?></a>
<?php
	} else {
		?>
<SCRIPT LANGUAGE="JavaScript">

function popUp(URL) {
day = new Date();
id = day.getTime();
eval("page" + id + " = window.open(URL, '" + id + "', 'toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=1,width=450,height=400,left = 500,top = 134');");
}

</script>
<A HREF="javascript:popUp('<?php echo $url; ?>')"><?php echo $text; ?></A>
		<?php
		
	}
}

function rate($id,$qesm) {
global $member,$theme_file;
$star_on = "themes/$theme_file/icons/rate_on.gif";
$star_off = "themes/$theme_file/icons/rate_off.gif";
?><script>
$(document).ready(function(){
	$("#rate_done").hide();
	$("#rate_load").hide();
	$("#str1").hover(function(){
		$("#str1").attr("src","<?php echo $star_on; ?>");
		$("#str2").attr("src","<?php echo $star_off; ?>");
		$("#str3").attr("src","<?php echo $star_off; ?>");
		$("#str4").attr("src","<?php echo $star_off; ?>");
		$("#str5").attr("src","<?php echo $star_off; ?>");
	});
	$("#str2").hover(function(){
		$("#str1").attr("src","<?php echo $star_on; ?>");
		$("#str2").attr("src","<?php echo $star_on; ?>");
		$("#str3").attr("src","<?php echo $star_off; ?>");
		$("#str4").attr("src","<?php echo $star_off; ?>");
		$("#str5").attr("src","<?php echo $star_off; ?>");
	});
	$("#str3").hover(function(){
		$("#str1").attr("src","<?php echo $star_on; ?>");
		$("#str2").attr("src","<?php echo $star_on; ?>");
		$("#str3").attr("src","<?php echo $star_on; ?>");
		$("#str4").attr("src","<?php echo $star_off; ?>");
		$("#str5").attr("src","<?php echo $star_off; ?>");
	});
	$("#str4").hover(function(){
		$("#str1").attr("src","<?php echo $star_on; ?>");
		$("#str2").attr("src","<?php echo $star_on; ?>");
		$("#str3").attr("src","<?php echo $star_on; ?>");
		$("#str4").attr("src","<?php echo $star_on; ?>");
		$("#str5").attr("src","<?php echo $star_off; ?>");
	});
	$("#str5").hover(function(){
		$("#str1").attr("src","<?php echo $star_on; ?>");
		$("#str2").attr("src","<?php echo $star_on; ?>");
		$("#str3").attr("src","<?php echo $star_on; ?>");
		$("#str4").attr("src","<?php echo $star_on; ?>");
		$("#str5").attr("src","<?php echo $star_on; ?>");
	});
	$("#str1").click(function() {
		$("#rate_done").hide();
		$("#rate_load").fadeIn(2000, function() {
			$("#rate_load").hide();
			$("#rate_done").fadeIn(2000, function() { $("#rate_done").fadeOut(4000, function() { }); });
		}); 
	});
	$("#str2").click(function() {
		$("#rate_done").hide();
		$("#rate_load").fadeIn(2000, function() {
			$("#rate_load").hide();
			$("#rate_done").fadeIn(2000, function() { $("#rate_done").fadeOut(4000, function() { }); });
		}); 
	});
	$("#str3").click(function() {
		$("#rate_done").hide();
		$("#rate_load").fadeIn(2000, function() {
			$("#rate_load").hide();
			$("#rate_done").fadeIn(2000, function() { $("#rate_done").fadeOut(4000, function() { }); });
		}); 
	});
	$("#str4").click(function() {
		$("#rate_done").hide();
		$("#rate_load").fadeIn(2000, function() {
			$("#rate_load").hide();
			$("#rate_done").fadeIn(2000, function() { $("#rate_done").fadeOut(4000, function() { }); });
		}); 
	});
	$("#str5").click(function() {

		$("#rate_load").fadeIn(2000, function() {
			$("#rate_load").hide();
			$("#rate_done").fadeIn(2000, function() { $("#rate_done").fadeOut(4000, function() { }); });
		}); 
	});
});
</script>
<?php
if($qesm == 'lesson') {
$mysql_ratefuntion_query = mysql_query("SELECT id,rate FROM afm_lessons_lessons WHERE id = '$id'");
$mysql_ratefuntion_row = mysql_fetch_array($mysql_ratefuntion_query);
$rate = $mysql_ratefuntion_row['rate'];
} elseif($qesm == 'flash') {
$mysql_ratefuntion_query = mysql_query("SELECT id,rate FROM afm_flashs_flashs WHERE id = '$id'");
$mysql_ratefuntion_row = mysql_fetch_array($mysql_ratefuntion_query);
$rate = $mysql_ratefuntion_row['rate'];
} elseif($qesm == 'pro') {
$mysql_ratefuntion_query = mysql_query("SELECT id,rate FROM afm_pro_pro WHERE id = '$id'");
$mysql_ratefuntion_row = mysql_fetch_array($mysql_ratefuntion_query);
$rate = $mysql_ratefuntion_row['rate'];
} elseif($qesm == 'vid') {
$mysql_ratefuntion_query = mysql_query("SELECT id,rate FROM afm_videos_videos WHERE id = '$id'");
$mysql_ratefuntion_row = mysql_fetch_array($mysql_ratefuntion_query);
$rate = $mysql_ratefuntion_row['rate'];
} elseif($qesm == 'news') {
$mysql_ratefuntion_query = mysql_query("SELECT id,rate FROM afm_news_news WHERE id = '$id'");
$mysql_ratefuntion_row = mysql_fetch_array($mysql_ratefuntion_query);
$rate = $mysql_ratefuntion_row['rate'];
} elseif($qesm == 'site') {
$mysql_ratefuntion_query = mysql_query("SELECT id,rate FROM afm_weblinks_sites WHERE id = '$id'");
$mysql_ratefuntion_row = mysql_fetch_array($mysql_ratefuntion_query);
$rate = $mysql_ratefuntion_row['rate'];
} elseif($qesm == 'topic') {
$mysql_ratefuntion_query = mysql_query("SELECT id,rate FROM afm_topics_topics WHERE id = '$id'");
$mysql_ratefuntion_row = mysql_fetch_array($mysql_ratefuntion_query);
$rate = $mysql_ratefuntion_row['rate'];
} elseif($qesm == 'image') {
$mysql_ratefuntion_query = mysql_query("SELECT id,rate FROM afm_images_images WHERE id = '$id'");
$mysql_ratefuntion_row = mysql_fetch_array($mysql_ratefuntion_query);
$rate = $mysql_ratefuntion_row['rate'];
}
//rating stars
?>
<span id="rating_stars">
<?php if($rate <= 0) { ?>
<a href="rate.php?t=<?php echo $qesm; ?>&v=1&id=<?php echo $id; ?>&m=min" target="rate">
<img id="str1" src="<?php echo $star_off; ?>" height="16" width="16"/></a>
<a href="rate.php?t=<?php echo $qesm; ?>&v=2&id=<?php echo $id; ?>&m=min" target="rate">
<img id="str2" src="<?php echo $star_off; ?>" height="16" width="16"/></a>
<a href="rate.php?t=<?php echo $qesm; ?>&v=1&id=<?php echo $id; ?>&m=pls" target="rate">
<img id="str3" src="<?php echo $star_off; ?>" height="16" width="16"/></a>
<a href="rate.php?t=<?php echo $qesm; ?>&v=2&id=<?php echo $id; ?>&m=pls" target="rate">
<img id="str4" src="<?php echo $star_off; ?>" height="16" width="16"/></a>
<a href="rate.php?t=<?php echo $qesm; ?>&v=3&id=<?php echo $id; ?>&m=pls" target="rate">
<img id="str5" src="<?php echo $star_off; ?>" height="16" width="16"/></a>
<script>	$("#rating_stars").mouseout(function() {
		$("#str1").attr("src","<?php echo $star_off; ?>");
		$("#str2").attr("src","<?php echo $star_off; ?>");
		$("#str3").attr("src","<?php echo $star_off; ?>");
		$("#str4").attr("src","<?php echo $star_off; ?>");
		$("#str5").attr("src","<?php echo $star_off; ?>");
	});
</script>
<?php } elseif($rate <= 5) { ?>
<a href="rate.php?t=<?php echo $qesm; ?>&v=1&id=<?php echo $id; ?>&m=min" target="rate">
<img id="str1" src="<?php echo $star_on; ?>" height="16" width="16"/></a>
<a href="rate.php?t=<?php echo $qesm; ?>&v=2&id=<?php echo $id; ?>&m=min" target="rate">
<img id="str2" src="<?php echo $star_off; ?>" height="16" width="16"/></a>
<a href="rate.php?t=<?php echo $qesm; ?>&v=1&id=<?php echo $id; ?>&m=pls" target="rate">
<img id="str3" src="<?php echo $star_off; ?>" height="16" width="16"/></a>
<a href="rate.php?t=<?php echo $qesm; ?>&v=2&id=<?php echo $id; ?>&m=pls" target="rate">
<img id="str4" src="<?php echo $star_off; ?>" height="16" width="16"/></a>
<a href="rate.php?t=<?php echo $qesm; ?>&v=3&id=<?php echo $id; ?>&m=pls" target="rate">
<img id="str5" src="<?php echo $star_off; ?>" height="16" width="16"/></a>
<script>	$("#rating_stars").mouseout(function() {
		$("#str1").attr("src","<?php echo $star_on; ?>");
		$("#str2").attr("src","<?php echo $star_off; ?>");
		$("#str3").attr("src","<?php echo $star_off; ?>");
		$("#str4").attr("src","<?php echo $star_off; ?>");
		$("#str5").attr("src","<?php echo $star_off; ?>");
	});
</script>
<?php } elseif($rate <= 40) { ?>
<a href="rate.php?t=<?php echo $qesm; ?>&v=1&id=<?php echo $id; ?>&m=min" target="rate">
<img id="str1" src="<?php echo $star_on; ?>" height="16" width="16"/></a>
<a href="rate.php?t=<?php echo $qesm; ?>&v=2&id=<?php echo $id; ?>&m=min" target="rate">
<img id="str2" src="<?php echo $star_on; ?>" height="16" width="16"/></a>
<a href="rate.php?t=<?php echo $qesm; ?>&v=1&id=<?php echo $id; ?>&m=pls" target="rate">
<img id="str3" src="<?php echo $star_off; ?>" height="16" width="16"/></a>
<a href="rate.php?t=<?php echo $qesm; ?>&v=2&id=<?php echo $id; ?>&m=pls" target="rate">
<img id="str4" src="<?php echo $star_off; ?>" height="16" width="16"/></a>
<a href="rate.php?t=<?php echo $qesm; ?>&v=3&id=<?php echo $id; ?>&m=pls" target="rate">
<img id="str5" src="<?php echo $star_off; ?>" height="16" width="16"/></a>
<script>	$("#rating_stars").mouseout(function() {
		$("#str1").attr("src","<?php echo $star_on; ?>");
		$("#str2").attr("src","<?php echo $star_on; ?>");
		$("#str3").attr("src","<?php echo $star_off; ?>");
		$("#str4").attr("src","<?php echo $star_off; ?>");
		$("#str5").attr("src","<?php echo $star_off; ?>");
	});
</script>
<?php } elseif($rate <= 100) { ?>
<a href="rate.php?t=<?php echo $qesm; ?>&v=1&id=<?php echo $id; ?>&m=min" target="rate">
<img id="str1" src="<?php echo $star_on; ?>" height="16" width="16"/></a>
<a href="rate.php?t=<?php echo $qesm; ?>&v=2&id=<?php echo $id; ?>&m=min" target="rate">
<img id="str2" src="<?php echo $star_on; ?>" height="16" width="16"/></a>
<a href="rate.php?t=<?php echo $qesm; ?>&v=1&id=<?php echo $id; ?>&m=pls" target="rate">
<img id="str3" src="<?php echo $star_on; ?>" height="16" width="16"/></a>
<a href="rate.php?t=<?php echo $qesm; ?>&v=2&id=<?php echo $id; ?>&m=pls" target="rate">
<img id="str4" src="<?php echo $star_off; ?>" height="16" width="16"/></a>
<a href="rate.php?t=<?php echo $qesm; ?>&v=3&id=<?php echo $id; ?>&m=pls" target="rate">
<img id="str5" src="<?php echo $star_off; ?>" height="16" width="16"/></a>
<script>	$("#rating_stars").mouseout(function() {
		$("#str1").attr("src","<?php echo $star_on; ?>");
		$("#str2").attr("src","<?php echo $star_on; ?>");
		$("#str3").attr("src","<?php echo $star_on; ?>");
		$("#str4").attr("src","<?php echo $star_off; ?>");
		$("#str5").attr("src","<?php echo $star_off; ?>");
	});
</script>
<?php } elseif($rate <= 160) { ?>
<a href="rate.php?t=<?php echo $qesm; ?>&v=1&id=<?php echo $id; ?>&m=min" target="rate">
<img id="str1" src="<?php echo $star_on; ?>" height="16" width="16"/></a>
<a href="rate.php?t=<?php echo $qesm; ?>&v=2&id=<?php echo $id; ?>&m=min" target="rate">
<img id="str2" src="<?php echo $star_on; ?>" height="16" width="16"/></a>
<a href="rate.php?t=<?php echo $qesm; ?>&v=1&id=<?php echo $id; ?>&m=pls" target="rate">
<img id="str3" src="<?php echo $star_on; ?>" height="16" width="16"/></a>
<a href="rate.php?t=<?php echo $qesm; ?>&v=2&id=<?php echo $id; ?>&m=pls" target="rate">
<img id="str4" src="<?php echo $star_on; ?>" height="16" width="16"/></a>
<a href="rate.php?t=<?php echo $qesm; ?>&v=3&id=<?php echo $id; ?>&m=pls" target="rate">
<img id="str5" src="<?php echo $star_off; ?>" height="16" width="16"/></a>
<script>	$("#rating_stars").mouseout(function() {
		$("#str1").attr("src","<?php echo $star_on; ?>");
		$("#str2").attr("src","<?php echo $star_on; ?>");
		$("#str3").attr("src","<?php echo $star_on; ?>");
		$("#str4").attr("src","<?php echo $star_on; ?>");
		$("#str5").attr("src","<?php echo $star_off; ?>");
	});
</script>
<?php } elseif($rate <= 210) { ?>
<a href="rate.php?t=<?php echo $qesm; ?>&v=1&id=<?php echo $id; ?>&m=min" target="rate">
<img id="str1" src="<?php echo $star_on; ?>" height="16" width="16"/></a>
<a href="rate.php?t=<?php echo $qesm; ?>&v=2&id=<?php echo $id; ?>&m=min" target="rate">
<img id="str2" src="<?php echo $star_on; ?>" height="16" width="16"/></a>
<a href="rate.php?t=<?php echo $qesm; ?>&v=1&id=<?php echo $id; ?>&m=pls" target="rate">
<img id="str3" src="<?php echo $star_on; ?>" height="16" width="16"/></a>
<a href="rate.php?t=<?php echo $qesm; ?>&v=2&id=<?php echo $id; ?>&m=pls" target="rate">
<img id="str4" src="<?php echo $star_on; ?>" height="16" width="16"/></a>
<a href="rate.php?t=<?php echo $qesm; ?>&v=3&id=<?php echo $id; ?>&m=pls" target="rate">
<img id="str5" src="<?php echo $star_on; ?>" height="16" width="16"/></a>
<script>	$("#rating_stars").mouseout(function() {
		$("#str1").attr("src","<?php echo $star_on; ?>");
		$("#str2").attr("src","<?php echo $star_on; ?>");
		$("#str3").attr("src","<?php echo $star_on; ?>");
		$("#str4").attr("src","<?php echo $star_on; ?>");
		$("#str5").attr("src","<?php echo $star_on; ?>");
	});
</script>
<?php } elseif($rate >= 211) { ?>
<a href="rate.php?t=<?php echo $qesm; ?>&v=1&id=<?php echo $id; ?>&m=min" target="rate">
<img id="str1" src="<?php echo $star_on; ?>" height="16" width="16"/></a>
<a href="rate.php?t=<?php echo $qesm; ?>&v=2&id=<?php echo $id; ?>&m=min" target="rate">
<img id="str2" src="<?php echo $star_on; ?>" height="16" width="16"/></a>
<a href="rate.php?t=<?php echo $qesm; ?>&v=1&id=<?php echo $id; ?>&m=pls" target="rate">
<img id="str3" src="<?php echo $star_on; ?>" height="16" width="16"/></a>
<a href="rate.php?t=<?php echo $qesm; ?>&v=2&id=<?php echo $id; ?>&m=pls" target="rate">
<img id="str4" src="<?php echo $star_on; ?>" height="16" width="16"/></a>
<a href="rate.php?t=<?php echo $qesm; ?>&v=3&id=<?php echo $id; ?>&m=pls" target="rate">
<img id="str5" src="<?php echo $star_on; ?>" height="16" width="16"/></a>
<script>	$("#rating_stars").mouseout(function() {
		$("#str1").attr("src","<?php echo $star_on; ?>");
		$("#str2").attr("src","<?php echo $star_on; ?>");
		$("#str3").attr("src","<?php echo $star_on; ?>");
		$("#str4").attr("src","<?php echo $star_on; ?>");
		$("#str5").attr("src","<?php echo $star_on; ?>");
	});
</script>
<?php } ?>

</span>
<img id="rate_done" src="themes/<?php echo $theme_file; ?>/icons/done.gif" height="16" width="16"/>
<img id="rate_load" src="themes/<?php echo $theme_file; ?>/icons/loading_circle.gif" height="16" width="16"/>
<?php
if($member == no) { } else {
?>

<?php
}
//rating stars-end
?>
<iframe name="rate" frameborder="0" height="0" width="0"></iframe>
<?php
}



function g2h($gre,$type="all") {
list($d, $m, $y) = explode('/', $gre);
if (($y>1582)||(($y==1582)&&($m>10))||(($y==1582)&&($m==10)&&($d>14))){
$jd=(int)((1461*($y+4800+(int)(($m-14)/12)))/4)+(int)((367*($m-2-12*((int)(($m-14)/12))))/12)-(int)((3*((int)(($y+4900+(int)(($m-14)/12))/100)))/4)+$d-32074;
}else{
$jd = 367*$y-(int)((7*($y+5001+(int)(($m-9)/7)))/4)+(int)((275*$m)/9)+$d+1729777;
}
$l=$jd-1948440+10632;
$n=(int)(($l-1)/10631);
$l=$l-10631*$n+354;
$j=((int)((10985-$l)/5316))*((int)((50*$l)/17719))+((int)($l/5670))*((int)((43*$l)/15238));
$l=$l-((int)((30-$j)/15))*((int)((17719*$j)/50))-((int)($j/16))*((int)((15238*$j)/43))+29 ;
$m=(int)((24*$l)/709);
$d=$l-(int)((709*$m)/24);
$y=30*$n+$j-30;
if ($type=="all") {return "$y/$m/$d";}
elseif ($type=="dd") {return "$d";}
elseif ($type=="mm") {return "$m";}
elseif ($type=="yy") {return "$y";}
}

function f_date($date) {
global $lang_date_hijri,$lang_date_christian,$mysql_maininfo_row;
if($mysql_maininfo_row['date_type'] == 'hijri') {
echo g2h(date("$date",time()),"dd");  
print '/';
echo g2h(date("$date",time()),"mm");  
print '/';
echo g2h(date("$date",time()),"yy");  
print ' '.$lang_date_hijri.'';
} else {
print $date;
print ' ';
print $lang_date_christian;
}
}

function send_button($url,$text) {
	echo '<form action="'.$url.'" method="post"><input type="submit" value="'.$text.'" /></form>';
}


?>

