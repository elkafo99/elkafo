<?php

@include ("themes/$theme_file/window_top.html");

?>
