<?php 
include("../connect.php");
$gid = $_GET['id'];
$mysql_videos_vdeos_pg_query = mysql_query("SELECT * FROM afm_videos_videos WHERE id = '$gid'");
$mysql_videos_vdeos_pg_row   = mysql_fetch_array($mysql_videos_vdeos_pg_query);

$settings_query = mysql_query("SELECT * FROM afm_videos_settings");
$settings_row   = mysql_fetch_array($settings_query);

print '<style>body{margin:0;}</style>';

?>
	<script type="text/javascript" src="media_player/swfobject.js"></script>
	<script type="text/javascript">
		swfobject.registerObject("player","9.0.98","expressInstall.swf");
		so.addVariable('skin', 'media_player/player_skin.swf');
	</script>

        <embed type="application/x-shockwave-flash" src="media_player/player-viral.swf" id="single" name="single" quality="high" allowfullscreen="true" wmode="opaque" flashvars="fullscreen=true&file=<?php print $mysql_videos_vdeos_pg_row['url']; ?>&image=video_image.php?id=<?php echo $mysql_videos_vdeos_pg_row['id']; ?>&skin=media_player/player_skin.swf&logo=<?php echo $settings_row['logo']; ?>" width="100%" height="99%">


