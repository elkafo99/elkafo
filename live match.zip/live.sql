-- phpMyAdmin SQL Dump
-- version 4.0.10.14
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Aug 30, 2016 at 09:56 PM
-- Server version: 5.6.30
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tsweqala_live`
--

-- --------------------------------------------------------

--
-- Table structure for table `afm_blocks`
--

CREATE TABLE IF NOT EXISTS `afm_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `content` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `file` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `position` int(11) NOT NULL,
  `tarteeb` int(11) NOT NULL,
  `page` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `afm_blocks`
--

INSERT INTO `afm_blocks` (`id`, `title`, `content`, `file`, `position`, `tarteeb`, `page`) VALUES
(1, 'Ù…Ø¨Ø§Ø±ÙŠØ§Øª Ø§Ù„ÙŠÙˆÙ…', '', 'todaymatch.php', 3, 3, 'index'),
(2, 'Ù…Ù„Ø®Øµ Ø§Ù„Ù…Ø¨Ø§Ø±ÙŠØ§Øª', '', 'lastvideo.php', 3, 2, 'index'),
(3, 'Ø§Ø¹Ù„Ø§Ù† ÙŠØ³Ø§Ø±', '<h1 style="text-align: center;"><strong>Ø§Ø¹Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù„Ø§Ù†</strong></h1>', 'no', 2, 1, 'all'),
(4, '', '<h1 style="text-align: center;"><strong>Ø§Ø¹Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù€Ù„Ø§Ù†</strong></h1>', 'no', 4, 1, 'all');

-- --------------------------------------------------------

--
-- Table structure for table `afm_categories`
--

CREATE TABLE IF NOT EXISTS `afm_categories` (
  `topics` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `lessons` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `programs` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `sounds` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `videos` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `images` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `flash` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `weblinks` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `news` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `afm_categories`
--

INSERT INTO `afm_categories` (`topics`, `lessons`, `programs`, `sounds`, `videos`, `images`, `flash`, `weblinks`, `news`) VALUES
('yes', 'no', 'no', 'no', 'yes', 'no', 'no', 'no', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `afm_contactus`
--

CREATE TABLE IF NOT EXISTS `afm_contactus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender` text NOT NULL,
  `email` text NOT NULL,
  `subject` text NOT NULL,
  `message` longtext NOT NULL,
  `date` text NOT NULL,
  `readed` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `afm_contactus`
--

INSERT INTO `afm_contactus` (`id`, `sender`, `email`, `subject`, `message`, `date`, `readed`) VALUES
(6, 'Ø§Ø­Ù…Ø¯', 'afm707@gmail.com', 'ØªØ¬Ø±Ø¨Ø© ÙÙ‚Ø·', 'ØªØ¬Ø±ÙŠØ¨ Ø§ØªØµÙ„ Ø¨Ù†Ø§', '11/07/2016', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `afm_control`
--

CREATE TABLE IF NOT EXISTS `afm_control` (
  `notes` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `afm_languages`
--

CREATE TABLE IF NOT EXISTS `afm_languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `file` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `afm_languages`
--

INSERT INTO `afm_languages` (`id`, `name`, `file`) VALUES
(1, 'English', 'en.php'),
(2, 'Ø¹Ø±Ø¨ÙŠ', 'ar.php');

-- --------------------------------------------------------

--
-- Table structure for table `afm_maininfo`
--

CREATE TABLE IF NOT EXISTS `afm_maininfo` (
  `sitename` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `address` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `defult_theme` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `defult_language` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `copyrights` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `keywords` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `rules` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `ajax` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `members_on` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `coments_guests` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `admin_email` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `favicon` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `close_yn` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `close_msg` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `closergstr_yn` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `closergstr_msg` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `date_type` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `version` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `site_create_date` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `afm_maininfo`
--

INSERT INTO `afm_maininfo` (`sitename`, `address`, `defult_theme`, `defult_language`, `copyrights`, `keywords`, `rules`, `ajax`, `members_on`, `coments_guests`, `admin_email`, `favicon`, `close_yn`, `close_msg`, `closergstr_yn`, `closergstr_msg`, `date_type`, `version`, `site_create_date`) VALUES
('Ø¨Ø« Ù…Ø¨Ø§Ø´Ø±', 'http://yoursite.com/', 'default', 'ar.php', NULL, 'Ø¨Ø« Ù…Ø¨Ø§Ø´Ø± , Ù…Ø¨Ø§Ø±ÙŠØ§Øª', NULL, 'on', 'off', 'on', 'design@hotmail.com', 'http://www.jobs.ie/content/images/no-logo.jpg', 'no', '<p>Ù…ØºÙ„Ù‚</p>', 'no', '', 'christian', '2.1', '');

-- --------------------------------------------------------

--
-- Table structure for table `afm_members`
--

CREATE TABLE IF NOT EXISTS `afm_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `password` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `email` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `sex` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `country` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `avatar` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `signature` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `level` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `title` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `autoactivate` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `notes` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `afm_members`
--

INSERT INTO `afm_members` (`id`, `username`, `password`, `email`, `sex`, `country`, `avatar`, `signature`, `level`, `title`, `autoactivate`, `notes`) VALUES
(1, 'admin', '4297f44b13955235245b2497399d7a93', 'afm707@gmail.com', 'male', '', '', '', 'admin', '<span style=background:red;border:black solid 1px;>Ø§Ù„Ù…Ø¯ÙŠØ± Ø§Ù„Ø¹Ø§Ù…</span>', 'yes', '');

-- --------------------------------------------------------

--
-- Table structure for table `afm_msgs`
--

CREATE TABLE IF NOT EXISTS `afm_msgs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `date` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `afm_online`
--

CREATE TABLE IF NOT EXISTS `afm_online` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `memid` text NOT NULL,
  `time` text NOT NULL,
  `ip` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=384 ;

--
-- Dumping data for table `afm_online`
--

INSERT INTO `afm_online` (`id`, `memid`, `time`, `ip`) VALUES
(383, 'no', '1472590225', '45.246.85.90');

-- --------------------------------------------------------

--
-- Table structure for table `afm_pages`
--

CREATE TABLE IF NOT EXISTS `afm_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `c2` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `c3` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `c4` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `c5` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `c6` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `c7` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `c8` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `n1` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `n2` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `n3` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `n4` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `n5` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `n6` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `n7` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `n8` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `url` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `afm_pages`
--

INSERT INTO `afm_pages` (`id`, `title`, `content`, `c2`, `c3`, `c4`, `c5`, `c6`, `c7`, `c8`, `n1`, `n2`, `n3`, `n4`, `n5`, `n6`, `n7`, `n8`, `url`) VALUES
(1, 'Bein sport 1', '<p>Ù‡Ù†Ø§ ÙƒÙˆØ¯ Ø§Ù„Ø¨Ø«</p>', '<p>ÙƒÙˆØ¯ Ø¨Ø« Ù…ØªÙˆØ³Ø·</p>', '<p>ÙƒÙˆØ¯ Ø¨Ø« Ø¨Ø·Ø¦</p>', '', '', '', '', '', 'Ø±Ø¦ÙŠØ³ÙŠ', 'Ù…ØªÙˆØ³Ø·', 'Ø¨Ø·Ø¦', '', '', '', '', '', 'bein1');

-- --------------------------------------------------------

--
-- Table structure for table `afm_themes`
--

CREATE TABLE IF NOT EXISTS `afm_themes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `file` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `afm_themes`
--

INSERT INTO `afm_themes` (`id`, `name`, `file`) VALUES
(14, 'nice_motorcycle', 'nice_motorcycle'),
(13, 'nice_blue', 'nice_blue'),
(12, 'default', 'default');

-- --------------------------------------------------------

--
-- Table structure for table `afm_topics_settings`
--

CREATE TABLE IF NOT EXISTS `afm_topics_settings` (
  `fast_stats` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `send_topic` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `topics_per_pg` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `show_sig` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `catpg_clms` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `afm_topics_settings`
--

INSERT INTO `afm_topics_settings` (`fast_stats`, `send_topic`, `topics_per_pg`, `show_sig`, `catpg_clms`) VALUES
('yes', 'no', '10', 'no', '1');

-- --------------------------------------------------------

--
-- Table structure for table `afm_topics_topics`
--

CREATE TABLE IF NOT EXISTS `afm_topics_topics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page` int(11) NOT NULL,
  `title` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `title2` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `vtitle` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `time` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `res1` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `res2` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `author` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `views` int(11) DEFAULT '0',
  `rate` int(11) DEFAULT NULL,
  `active` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `allow_coments` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `date` text NOT NULL,
  `image` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `image2` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `com` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `link` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `live` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
